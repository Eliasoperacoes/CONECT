/**
 * Painel lateral, parte "Sessões": o que o vigia (relogin.js, no service
 * worker, a cada 2 minutos) viu em cada B2B, o botão "Entrar agora" e o
 * registro das quedas e dos relogins. Atualiza sozinho: nada de clicar em
 * "conferir" para saber se caiu.
 */
(() => {
  const $ = (id) => document.getElementById(id);
  const ROTULO = { ok: 'logado', login: 'na tela de login', travada: 'travada (reconectando): dando F5', fora: 'aba fechada', 'sem-resposta': 'carregando…' };
  const nomeDe = (fornecedor) => Cotacao.SITES.find((s) => s.fornecedor === fornecedor)?.nome ?? fornecedor;
  const hora = (ms) => new Date(ms).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

  /** Pede ao service worker (a fila de relogin é uma só, a dele) */
  const pedir = (msg) => chrome.runtime.sendMessage({ sessoes: msg.sessoes, fornecedor: msg.fornecedor });

  const entrar = async (site, botao) => {
    botao.disabled = true;
    botao.textContent = 'Entrando…';
    await pedir({ sessoes: 'relogar', fornecedor: site.fornecedor }).catch(() => {});
  };

  // Lucios e CHG não entram sozinhos (relogin.js, SEM_AUTOMATICO): o botão só abre a aba
  const abrir = async (site) => {
    const [aba] = await chrome.tabs.query({ url: site.abas });
    if (!aba) return;
    await chrome.tabs.update(aba.id, { active: true });
    await chrome.windows.update(aba.windowId, { focused: true });
  };

  // Só textContent: o detalhe pode trazer texto do site e do Chrome
  const desenhar = ({ sessoes = {}, relogins = [] }) => {
    $('sessoes').replaceChildren(
      ...Cotacao.SITES.map((site) => {
        const s = sessoes[site.fornecedor];
        const situacao = s?.situacao ?? 'sem-resposta';
        const li = document.createElement('li');
        li.className = `sessao ${situacao}`;
        const texto = document.createElement('span');
        const motivo = Relogin.SEM_AUTOMATICO[site.fornecedor];
        const espera = situacao !== 'login' ? '' : motivo ? ` · entre à mão: ${motivo}` : s.falhas >= 2 ? ' · tentou 2 vezes, entre à mão' : '';
        texto.textContent = `${site.nome}: ${ROTULO[situacao] ?? situacao}${espera}`;
        li.append(texto);
        if (situacao === 'login') {
          const botao = document.createElement('button');
          botao.textContent = motivo ? 'Abrir a aba' : 'Entrar agora';
          botao.addEventListener('click', () => void (motivo ? abrir(site) : entrar(site, botao)));
          li.append(botao);
        }
        return li;
      })
    );
    const visto = Object.values(sessoes).map((s) => s.vistoEm ?? 0).sort((a, b) => b - a)[0];
    $('sessoes-visto').textContent = visto ? `Conferido às ${hora(visto).slice(-5)} · confere sozinho a cada 2 min` : 'Conferindo…';
    $('relogins').replaceChildren(
      ...relogins.slice(-20).reverse().map((r) => {
        const li = document.createElement('li');
        li.textContent = `${hora(r.quando)} · ${nomeDe(r.fornecedor)} · ${r.resultado} · ${r.detalhe}`;
        return li;
      })
    );
  };

  const ler = () => chrome.storage.local.get(['sessoes', 'relogins']).then(desenhar);
  chrome.storage.onChanged.addListener((m) => {
    if (m.sessoes || m.relogins) void ler();
  });
  // O CNPJ do login: só no storage deste Chrome (relogin.js, lerCnpj)
  // Salva enquanto digita ou cola (o botão também): no PC de Compras o clique
  // em "Salvar" não salvava (11/11/2026); assim não depende dele
  const mostrarCnpj = (cnpj) => ($('cnpj-salvo').textContent = cnpj ? `CNPJ salvo: ${cnpj}` : 'Nenhum CNPJ salvo');
  const salvarCnpj = async () => {
    const cnpj = $('cnpj-login').value.trim();
    try {
      await chrome.storage.local.set({ cnpjLogin: cnpj });
      mostrarCnpj(cnpj);
    } catch (e) {
      $('cnpj-salvo').textContent = `Não salvou: ${e.message}`;
    }
  };
  chrome.storage.local.get('cnpjLogin').then(({ cnpjLogin }) => {
    $('cnpj-login').value = cnpjLogin ?? '';
    mostrarCnpj(cnpjLogin);
  });
  $('cnpj-login').addEventListener('input', () => void salvarCnpj());

  // O login da Lucios (relogin.js, lerGuardado): só no storage deste Chrome.
  // A senha nunca aparece de volta na tela, só se está guardada
  // (o tamanho da senha, para conferir sem mostrá-la)
  const mostrarLucios = (g) => {
    const ok = g?.usuario && g?.senha;
    $('lucios-salvo').textContent = ok ? `Login da Lucios guardado: usuário ${g.usuario}, senha com ${g.senha.length} caracteres` : 'Login da Lucios não guardado';
    $('lucios-senha').placeholder = ok ? 'Senha guardada (digite para trocar)' : 'Senha';
  };
  // Uma cópia na memória e as gravações em fila, sempre do objeto inteiro: ler
  // o storage a cada tecla deixava uma gravação velha terminar por cima da
  // nova, e a senha ficava guardada pela metade (11/11/2026)
  let guardados = null;
  let gravando = Promise.resolve();
  const salvarLucios = () => {
    if (!guardados) return;
    const atual = guardados.lucios ?? {};
    guardados.lucios = {
      usuario: $('lucios-usuario').value.trim() || atual.usuario || '',
      senha: $('lucios-senha').value || atual.senha || '',
    };
    const copia = structuredClone(guardados);
    gravando = gravando.then(() => chrome.storage.local.set({ loginsGuardados: copia })).then(() => mostrarLucios(copia.lucios), (e) => ($('lucios-salvo').textContent = `Não salvou: ${e.message}`));
  };
  chrome.storage.local.get('loginsGuardados').then(({ loginsGuardados }) => {
    guardados = loginsGuardados ?? {};
    $('lucios-usuario').value = guardados.lucios?.usuario ?? '';
    mostrarLucios(guardados.lucios);
  });
  $('lucios-usuario').addEventListener('input', salvarLucios);
  $('lucios-senha').addEventListener('input', salvarLucios);
  $('salvar-cnpj').addEventListener('click', () => void salvarCnpj());
  $('conferir-sessoes').addEventListener('click', () => void pedir({ sessoes: 'vigiar' }).catch(() => {}));
  void ler();
  // Abriu o painel: confere já, sem esperar a volta do vigia
  void pedir({ sessoes: 'vigiar' }).catch(() => {});
})();
