/**
 * Utilidades dos leitores. Script comum, carregado antes deles.
 */
(() => {
  // No máximo N chamadas ao mesmo tempo (os similares geram dezenas)
  const limitar = (buscar, n) => {
    let ativas = 0;
    const fila = [];
    const proxima = () => {
      if (ativas >= n || !fila.length) return;
      ativas++;
      const { args, ok, falha } = fila.shift();
      buscar(...args).then(ok, falha).finally(() => { ativas--; proxima(); });
    };
    return (...args) => new Promise((ok, falha) => { fila.push({ args, ok, falha }); proxima(); });
  };

  /**
   * Resposta parcial do ASP.NET (UpdatePanel, Lucios): "tamanho|tipo|id|conteúdo|"
   * em sequência. O tamanho conta os caracteres do conteúdo, que pode ter "|".
   * → { paineis: {id: html}, campos: {nome: valor}, redirecionar }. Fora do
   * formato (página de login, erro) devolve null.
   */
  const lerDelta = (texto) => {
    if (typeof texto !== 'string' || !/^\d+\|/.test(texto)) return null;
    const r = { paineis: {}, campos: {}, redirecionar: null, erro: null };
    let i = 0;
    const ate = (fim) => {
      const j = texto.indexOf('|', i);
      if (j < 0) throw new Error(fim);
      const parte = texto.slice(i, j);
      i = j + 1;
      return parte;
    };
    try {
      while (i < texto.length) {
        const tamanho = Number(ate('tamanho'));
        const tipo = ate('tipo');
        const id = ate('id');
        const conteudo = texto.slice(i, i + tamanho);
        i += tamanho;
        if (texto[i] !== '|') return null;
        i++;
        if (tipo === 'updatePanel') r.paineis[id] = conteudo;
        else if (tipo === 'hiddenField') r.campos[id] = conteudo;
        else if (tipo === 'pageRedirect') r.redirecionar = decodeURIComponent(conteudo);
        else if (tipo === 'error') r.erro = conteudo || id;
      }
    } catch {
      return null;
    }
    return r;
  };

  globalThis.LeitoresComum = { limitar, lerDelta };
})();
