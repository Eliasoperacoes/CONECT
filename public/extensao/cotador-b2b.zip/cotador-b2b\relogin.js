/**
 * RELOGAR SOZINHO com a senha que o Chrome guardou (Elias, 11/11/2026: "todas
 * as abas possuem senhas salvas"). A extensão nunca lê, guarda nem manda a
 * senha: ela só clica, e quem preenche é o gerenciador de senhas do Chrome.
 *
 * O Chrome só entrega a senha preenchida à página depois de um clique DE
 * VERDADE; clique de script (el.click()) não conta, e o site receberia a
 * senha vazia. O clique vai pelo modo de depuração (chrome.debugger), que o
 * Chrome trata como do usuário — enquanto ele está ligado, aparece a faixa
 * "Cotador B2B está depurando este navegador", que some ao terminar.
 *
 * Regras que não podem cair (login errado em sequência bloqueia a conta no
 * fornecedor):
 *   - nada é enviado com a senha ou outro campo do login vazio;
 *   - nenhuma tecla Enter num campo antes de tudo preenchido (Enter envia o
 *     formulário — foi assim que a 1ª versão quase mandou o CNPJ vazio);
 *   - um relogin por vez (dois ao mesmo tempo disputavam a depuração e a aba
 *     da frente: "Another debugger is already attached", 11/11/2026);
 *   - no automático, uma tentativa por site a cada 15 min, e depois de 2
 *     falhas seguidas para e avisa até alguém entrar à mão.
 *
 * Script comum, sem import/export (como cotacao.js). Roda no service worker
 * (o vigia e a fila); o painel pede pelo chrome.runtime.
 */
(() => {
  /**
   * Roda DENTRO da aba (por isso não usa nada de fora da função). Sem campo
   * de senha visível, não é tela de login: devolve null. Senão, onde clicar
   * (o centro de cada campo, na tela) e o que já está preenchido — só se está,
   * nunca o valor.
   */
  function telaDeLogin() {
    const visivel = (el) => !!el && !el.disabled && (typeof el.checkVisibility === 'function' ? el.checkVisibility() : true);
    const senha = [...document.querySelectorAll('input[type="password"]')].find(visivel);
    if (!senha) return null;

    // O que pertence a este login: o formulário, ou o bloco em volta da senha
    // (site em React/Angular costuma não ter <form>)
    let escopo = senha.form;
    if (!escopo) {
      escopo = senha.parentElement;
      for (let i = 0; i < 5 && escopo.parentElement && !escopo.querySelector('button, input[type="submit"], [role="button"]'); i++) escopo = escopo.parentElement;
    }

    // Rola UMA vez, até a senha, e só então mede: rolar até cada campo
    // deixava errada a posição dos medidos antes, e o clique pulava de linha
    senha.scrollIntoView?.({ block: 'center' });
    const ponto = (el) => {
      if (!el) return null;
      const r = el.getBoundingClientRect();
      return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
    };
    // O nome do campo na tela (para dizer qual ficou vazio), nunca o valor
    // ...e, sem <label for>, o texto logo antes do campo (Barros: "CNPJ"
    // escrito em cima, solto). Só o vizinho imediato, e sem campo dentro:
    // senão o "CNPJ" de cima viraria o nome do usuário também
    const textoAntes = (el) => {
      for (let e = el; e && e !== escopo; e = e.parentElement) {
        const antes = e.previousElementSibling;
        if (antes) return antes.matches('input') || antes.querySelector('input') ? '' : antes.textContent;
      }
      return '';
    };
    const rotulo = (el) =>
      (el.labels?.[0]?.textContent || el.getAttribute('placeholder') || el.getAttribute('aria-label') || textoAntes(el) || el.getAttribute('name') || 'campo')
        .replace(/\s+/g, ' ').trim().slice(0, 40);
    // Campo com máscara mostra "__.___.___/____-__" vazio: sem letra nem número é vazio
    const vazio = (el) => !/[0-9a-z@]/i.test(el.value);

    // Os campos de texto antes da senha: usuário, e às vezes o CNPJ (Sky, Barros)
    const todos = [...escopo.querySelectorAll('input')];
    const campos = todos
      .slice(0, todos.indexOf(senha))
      .filter((c) => ['', 'text', 'email', 'tel'].includes((c.getAttribute('type') ?? '').toLowerCase()) && visivel(c))
      .map((c) => ({ ponto: ponto(c), vazio: vazio(c), rotulo: rotulo(c) }));

    const ENTRAR = /^(entrar|acessar|login|logar|log ?in|sign ?in|continuar|ok)$/i;
    // O texto do botão, ou a descrição da imagem dele (Lucios, ASP.NET: o
    // "Entrar" é uma imagem; o texto só existe no alt)
    const texto = (el) =>
      (el.textContent || el.value || el.getAttribute('alt') || el.getAttribute('title') || el.querySelector?.('img')?.getAttribute('alt') || '').replace(/\s+/g, ' ').trim();
    const porTexto = (raiz) => [...raiz.querySelectorAll('button, input[type="submit"], input[type="button"], input[type="image"], a, [role="button"]')].find((b) => visivel(b) && ENTRAR.test(texto(b)));
    const botao =
      [...escopo.querySelectorAll('button[type="submit"], input[type="submit"], input[type="image"]')].find(visivel) ??
      (senha.form ? [...senha.form.querySelectorAll('button:not([type])')].find(visivel) : null) ??
      porTexto(escopo) ??
      porTexto(document) ??
      null;

    // "Manter conectado neste dispositivo" (DPK): marcado, o site derruba menos
    const manter = [...escopo.querySelectorAll('input[type="checkbox"]')].find((c) => {
      const t = (c.labels?.[0]?.textContent || c.parentElement?.textContent || '').trim();
      return visivel(c) && !(c.checked ?? c.hasAttribute('checked')) && /manter|lembrar|permanecer|continuar conectado/i.test(t);
    });

    // Preenchido (ou em prévia) pelo Chrome: :autofill casa nos dois estados
    const doChrome = (el) => {
      for (const seletor of [':autofill', ':-webkit-autofill']) {
        try { if (el.matches(seletor)) return true; } catch { /* navegador sem o seletor */ }
      }
      return false;
    };
    const entradas = todos.slice(0, todos.indexOf(senha));
    const marcadaPeloChrome = doChrome(senha) || entradas.some(doChrome);
    return {
      campos,
      senha: ponto(senha),
      botao: ponto(botao),
      manter: ponto(manter ?? null),
      senhaPreenchida: senha.value.length > 0,
      marcadaPeloChrome,
    };
  }

  /**
   * O passo depois do "Entrar", também DENTRO da aba: o que o site pergunta
   * depois de aceitar a senha. Só texto da tela, nada da conta. Devolve
   * 'feito' quando agiu, ou null quando a tela não pede nada.
   *   botao:    clica no botão com esse texto (DPK: o CNPJ já vem marcado)
   *   escolher: na lista, a opção com esse texto, e depois o botão (Sky: a loja)
   */
  function passoDepois(passo) {
    const visivel = (el) => !!el && !el.disabled && (typeof el.checkVisibility === 'function' ? el.checkVisibility() : true);
    const texto = (el) => (el.textContent || el.value || '').replace(/\s+/g, ' ').trim();
    const botao = new RegExp(passo.botao, 'i');
    const alvo = [...document.querySelectorAll('button, input[type="submit"], input[type="button"], a, [role="button"]')].find((b) => visivel(b) && botao.test(texto(b)));
    if (!alvo) return null;
    if (passo.escolher) {
      const opcao = new RegExp(passo.escolher, 'i');
      const lista = [...document.querySelectorAll('select')].find((s) => visivel(s) && [...s.options].some((o) => opcao.test(o.textContent)));
      if (!lista) return null;
      const escolhida = [...lista.options].find((o) => opcao.test(o.textContent));
      if (lista.value !== escolhida.value) {
        lista.value = escolhida.value;
        lista.dispatchEvent(new Event('change', { bubbles: true }));
      }
    }
    alvo.click();
    return 'feito';
  }

  /**
   * DENTRO da aba, logo antes do clique: no ponto está mesmo o botão de
   * entrar? Um aviso de erro que aparece empurra a tela, e o clique da
   * Barros caiu em "Esqueci minha senha" (11/11/2026).
   */
  function ehOBotaoDeEntrar({ x, y }) {
    const el = document.elementFromPoint(x, y)?.closest('button, input, a, [role="button"]');
    if (!el) return false;
    const texto = (el.textContent || el.value || el.getAttribute('alt') || el.getAttribute('title') || el.querySelector?.('img')?.getAttribute('alt') || '').replace(/\s+/g, ' ').trim();
    return ['submit', 'image'].includes(el.getAttribute('type')) || /^(entrar|acessar|login|logar|log ?in|sign ?in|continuar|ok)$/i.test(texto);
  }

  // Os passos de cada site depois da senha (Elias, 11/11/2026, com os prints)
  const DEPOIS_DO_ENTRAR = {
    dpk: { botao: '^fechar e manter logado$' },
    sky: { escolher: '\\(PIRA\\)', botao: '^entrar$' },
  };

  // Os que ficam no aviso, não no automático (Elias, 11/11/2026). O captcha
  // existe para barrar automação: a extensão não tenta passar por ele
  const SEM_AUTOMATICO = {
    chg:'pede para confirmar que é humano (captcha)',
  };

  const esperar = (ms) => new Promise((ok) => setTimeout(ok, ms));
  let pausa = 400; // os testes zeram

  /**
   * Olha a aba. Só o null explícito da página é "não está no login"; a página
   * no meio de uma navegação (erro, ou sem resultado) vira "sem resposta"
   * (undefined) — e "sem resposta" nunca conta como entrou.
   */
  const olhar = async (tabId) => {
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: telaDeLogin });
      return r?.result;
    } catch {
      return undefined;
    }
  };

  const darPasso = async (tabId, passo) => {
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: passoDepois, args: [passo] });
      return r?.result ?? null;
    } catch {
      return null;
    }
  };

  /** DENTRO da aba: sem verificação da Cloudflare, ou ela já respondeu */
  function verificacaoPronta() {
    const resposta = document.querySelector('input[name="cf-turnstile-response"]');
    return !resposta || resposta.value.length > 0;
  }

  /** Espera a verificação anti-robô dar "Sucesso" (até 15 s); false se não deu */
  const esperarVerificacao = async (tabId) => {
    for (let passou = 0; passou <= 15000; passou += 1000) {
      try {
        const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: verificacaoPronta });
        if (r?.result !== false) return true;
      } catch {
        return true; // a página navegou: segue, e o laço de depois confere se entrou
      }
      await esperar(Math.min(1000, pausa * 3));
    }
    return false;
  };

  const conferirBotao = async (tabId, ponto) => {
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: ehOBotaoDeEntrar, args: [ponto] });
      return r?.result === true;
    } catch {
      return false;
    }
  };

  // O campo de CNPJ que o Chrome só sugere e não preenche (Sky, Barros). O
  // valor fica no storage deste Chrome, digitado no painel — nunca no código:
  // o pacote da extensão é público no CONECTA (/extensao)
  // Campo que aceita e-mail fica de fora: "E-mail ou CNPJ" (Vespor) entra por
  // e-mail, e o CNPJ ali seria uma tentativa errada
  const CAMPO_CNPJ = /^(?!.*e-?mail).*(cnpj|cpf)/i;
  const lerCnpj = async () => (await chrome.storage.local.get('cnpjLogin')).cnpjLogin?.trim() || null;

  // O LOGIN GUARDADO PELA EXTENSÃO, para o site em que o Chrome não entrega a
  // senha (Lucios, http: só oferece a conta numa lista que a depuração não
  // alcança — testado em 11/11/2026). Digitado no painel e guardado só no
  // storage deste Chrome; nunca no código, no registro nem fora do PC
  const lerGuardado = async (fornecedor) => {
    const g = (await chrome.storage.local.get('loginsGuardados')).loginsGuardados?.[fornecedor];
    return g?.usuario && g?.senha ? g : null;
  };

  const enviar = (alvo, metodo, params) => chrome.debugger.sendCommand(alvo, metodo, params);

  const clicar = async (alvo, { x, y }) => {
    const base = { x, y, button: 'left', clickCount: 1 };
    await enviar(alvo, 'Input.dispatchMouseEvent', { ...base, type: 'mousePressed' });
    await enviar(alvo, 'Input.dispatchMouseEvent', { ...base, type: 'mouseReleased' });
  };

  const enter = async (alvo) => {
    await enviar(alvo, 'Input.dispatchKeyEvent', { type: 'rawKeyDown', key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13 });
    await enviar(alvo, 'Input.dispatchKeyEvent', { type: 'keyUp', key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13 });
  };

  /** Limpa o campo em foco (Ctrl+A e apagar): a máscara deixa "__.___" nele */
  const limparCampo = async (alvo) => {
    await enviar(alvo, 'Input.dispatchKeyEvent', { type: 'rawKeyDown', key: 'a', code: 'KeyA', windowsVirtualKeyCode: 65, modifiers: 2, commands: ['selectAll'] });
    await enviar(alvo, 'Input.dispatchKeyEvent', { type: 'keyUp', key: 'a', code: 'KeyA', windowsVirtualKeyCode: 65, modifiers: 2 });
    await enviar(alvo, 'Input.dispatchKeyEvent', { type: 'rawKeyDown', key: 'Backspace', code: 'Backspace', windowsVirtualKeyCode: 8 });
    await enviar(alvo, 'Input.dispatchKeyEvent', { type: 'keyUp', key: 'Backspace', code: 'Backspace', windowsVirtualKeyCode: 8 });
  };

  /** Digita tecla por tecla, como uma pessoa: a máscara que recusa o texto colado aceita */
  const digitar = async (alvo, texto) => {
    for (const ch of texto) {
      await enviar(alvo, 'Input.dispatchKeyEvent', { type: 'keyDown', key: ch, text: ch });
      await enviar(alvo, 'Input.dispatchKeyEvent', { type: 'keyUp', key: ch });
    }
  };

  /**
   * Põe o CNPJ no campo: limpa e cola; se a página não aceitou, limpa e
   * digita só os números. Devolve a tela depois.
   */
  const porCnpj = async (alvo, tabId, campo, cnpj) => {
    await clicar(alvo, campo.ponto);
    await limparCampo(alvo);
    await enviar(alvo, 'Input.insertText', { text: cnpj });
    await esperar(pausa);
    let tela = await olhar(tabId);
    const aindaVazio = (t) => t?.campos.find((c) => c.vazio && CAMPO_CNPJ.test(c.rotulo));
    if (aindaVazio(tela)) {
      await clicar(alvo, campo.ponto);
      await limparCampo(alvo);
      await digitar(alvo, cnpj.replace(/\D/g, ''));
      await esperar(pausa);
      tela = await olhar(tabId);
    }
    return { tela, entrou: !aindaVazio(tela) };
  };

  /** O que impede de enviar o login; null quando está tudo preenchido */
  const faltando = (tela) => {
    if (!tela.senhaPreenchida)
      return tela.marcadaPeloChrome
        ? 'o Chrome mostrou a senha mas não a entregou ao site'
        : 'o Chrome não preencheu a senha (sem senha salva para este site?)';
    const vazio = tela.campos.find((c) => c.vazio);
    return vazio ? `o campo "${vazio.rotulo}" ficou vazio: o Chrome não preenche esse sozinho` : null;
  };

  // Os sites com relogin em andamento: a cotação não dá F5 no meio dele
  const relogando = new Set();

  /**
   * Relogar um site. Devolve { resultado, detalhe }:
   *   sem-aba · ja-logado · relogou · falhou
   */
  const relogarJa = async (site, { espera = 20000 } = {}) => {
    const [aba] = await chrome.tabs.query({ url: site.abas });
    if (!aba) return { resultado: 'sem-aba', detalhe: `nenhuma aba do ${site.nome} aberta` };
    let tela = await olhar(aba.id);
    if (tela === null) return { resultado: 'ja-logado', detalhe: 'a aba não está na tela de login' };
    if (!tela) return { resultado: 'falhou', detalhe: 'a aba não respondeu (carregando?)' };
    if (!tela.senha) return { resultado: 'falhou', detalhe: 'campo de senha sem posição na tela' };

    const alvo = { tabId: aba.id };
    relogando.add(site.fornecedor);
    await chrome.debugger.attach(alvo, '1.3');
    try {
      // Clicar em cada campo libera o que o Chrome preencheu nele
      for (const c of tela.campos) {
        await clicar(alvo, c.ponto);
        await esperar(pausa);
      }
      await clicar(alvo, tela.senha);
      await esperar(pausa);
      tela = await olhar(aba.id);
      // Só depois dos cliques o vazio é de verdade (antes, o que o Chrome
      // preencheu aparece vazio para a página): o CNPJ vai só no que ficou vazio
      // O Chrome não entregou a senha e há login guardado: digita usuário e senha
      const guardado = tela && !tela.senhaPreenchida && tela.campos.length ? await lerGuardado(site.fornecedor) : null;
      if (guardado) {
        for (const [ponto, texto] of [[tela.campos.at(-1).ponto, guardado.usuario], [tela.senha, guardado.senha]]) {
          await clicar(alvo, ponto);
          await limparCampo(alvo);
          await enviar(alvo, 'Input.insertText', { text: texto });
          await esperar(pausa);
        }
        tela = await olhar(aba.id);
      }
      const cnpjVazio = tela?.campos.find((c) => c.vazio && CAMPO_CNPJ.test(c.rotulo));
      const cnpj = cnpjVazio && (await lerCnpj());
      if (cnpjVazio && !cnpj) return { resultado: 'falhou', detalhe: `o campo "${cnpjVazio.rotulo}" ficou vazio (cadastre o CNPJ no painel)` };
      if (cnpj) {
        const r = await porCnpj(alvo, aba.id, cnpjVazio, cnpj);
        if (!r.entrou) return { resultado: 'falhou', detalhe: `o CNPJ não entrou no campo "${cnpjVazio.rotulo}" (colado e digitado)` };
        tela = r.tela;
      }
      if (tela) {
        const falta = faltando(tela);
        if (falta) return { resultado: 'falhou', detalhe: falta };
        if (tela.manter) {
          await clicar(alvo, tela.manter);
          await esperar(pausa);
          tela = (await olhar(aba.id)) ?? tela;
        }
        // A verificação da Cloudflare (Vespor) precisa dar "Sucesso" antes do
        // Entrar; sem ela, o clique é uma tentativa recusada
        if (!(await esperarVerificacao(aba.id))) return { resultado: 'falhou', detalhe: 'a verificação anti-robô (Cloudflare) não passou: não clicou em entrar' };
        if (tela.botao) {
          if (!(await conferirBotao(aba.id, tela.botao))) return { resultado: 'falhou', detalhe: 'o botão de entrar não estava onde a extensão ia clicar: não clicou' };
          await clicar(alvo, tela.botao);
        } else await enter(alvo); // tudo preenchido: aqui o Enter é o "Entrar"
      }

      // Espera a tela de login sumir, dando os passos que o site pedir no
      // caminho. "Entrou" é sem login e sem passo pendente duas vezes seguidas
      const passo = DEPOIS_DO_ENTRAR[site.fornecedor];
      let passos = 0;
      let limpas = 0;
      for (let passou = 0; passou < espera; passou += 1000) {
        await esperar(Math.min(1000, pausa * 3));
        if (passo && passos < 3 && (await darPasso(aba.id, passo)) === 'feito') {
          passos++;
          limpas = 0;
          continue;
        }
        const agora = await olhar(aba.id);
        limpas = agora === null ? limpas + 1 : 0;
        if (limpas >= 2) return { resultado: 'relogou', detalhe: passos ? `entrou (${passos} passo(s) depois da senha)` : 'entrou' };
      }
      return { resultado: 'falhou', detalhe: 'clicou em entrar e a tela de login continuou (senha errada, captcha ou código?)' };
    } finally {
      await chrome.debugger.detach(alvo).catch(() => {});
      relogando.delete(site.fornecedor);
    }
  };

  // Um de cada vez, venha do vigia, do painel ou da cotação
  let vez = Promise.resolve();
  const relogar = (site, opcoes) => {
    const este = vez.then(() => relogarJa(site, opcoes));
    vez = este.catch(() => {});
    return este;
  };

  // O registro: cada queda e cada relogin, por site, para medir quem cai e quanto o automático resolve
  const MAXIMO_REGISTROS = 300;
  const registrar = async (fornecedor, resultado, detalhe) => {
    const { relogins = [] } = await chrome.storage.local.get('relogins');
    relogins.push({ fornecedor, resultado, detalhe, quando: Date.now() });
    await chrome.storage.local.set({ relogins: relogins.slice(-MAXIMO_REGISTROS) });
  };

  /** A aba do site: `fora` (sem aba), `login` (na tela de login), `ok` ou `sem-resposta` */
  /**
   * DENTRO da aba: a página parou de falar com o servidor? O site em Blazor
   * (Haifer) não volta para o login quando a sessão cai: mostra "tentando
   * reconectar" e fica ali, sem campo de senha — e parecia logado (11/11/2026).
   */
  function paginaTravada() {
    const modal = document.getElementById('components-reconnect-modal');
    if (modal && (typeof modal.checkVisibility === 'function' ? modal.checkVisibility() : true)) return true;
    const PARADA = /tentando reconectar|reconex[ãa]o falhou|attempting to reconnect|could not reconnect|reconnection failed|failed to rejoin|rejoining the server/i;
    return PARADA.test((document.body?.innerText ?? '').slice(0, 5000));
  }

  /** A aba do site: `fora` (sem aba), `login` (na tela de login), `travada`, `ok` ou `sem-resposta` */
  const sessaoDoSite = async (site) => {
    const [aba] = await chrome.tabs.query({ url: site.abas });
    if (!aba) return 'fora';
    const tela = await olhar(aba.id);
    if (tela) return 'login';
    if (tela === undefined) return 'sem-resposta';
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId: aba.id }, func: paginaTravada });
      if (r?.result === true) return 'travada';
    } catch { /* sem resposta: conta como logado, como antes */ }
    return 'ok';
  };

  // A página travada leva F5 (no máximo um a cada 5 min): aí aparece o login
  const INTERVALO_F5_MS = 5 * 60 * 1000;

  // ------------------------------------------------------------
  // O VIGIA: a cada 2 minutos (servico.js), sem ninguém clicar
  // ------------------------------------------------------------
  const INTERVALO_TENTATIVA_MS = 15 * 60 * 1000;
  const MAXIMO_FALHAS = 2;

  /**
   * Traz a aba para a frente só durante o relogin (o Chrome preenche a senha
   * na aba visível) e devolve a que estava antes, na mesma janela.
   */
  const naFrente = async (site, fazer) => {
    const [aba] = await chrome.tabs.query({ url: site.abas });
    if (!aba) return fazer();
    const [antes] = await chrome.tabs.query({ active: true, windowId: aba.windowId });
    if (antes?.id !== aba.id) await chrome.tabs.update(aba.id, { active: true });
    try {
      return await fazer();
    } finally {
      if (antes && antes.id !== aba.id) await chrome.tabs.update(antes.id, { active: true }).catch(() => {});
    }
  };

  const avisar = (site, mensagem) =>
    chrome.notifications?.create(`relogin-${site.fornecedor}`, {
      type: 'basic',
      iconUrl: 'icone.png',
      title: `${site.nome}: entre no site`,
      message: mensagem,
      requireInteraction: true,
      priority: 2,
    });

  /** Uma volta: confere cada site e reloga o que caiu. Devolve o estado guardado. */
  const vigiar = async (sites, { agora = Date.now() } = {}) => {
    const { sessoes = {} } = await chrome.storage.local.get('sessoes');
    for (const site of sites) {
      const antes = sessoes[site.fornecedor] ?? { falhas: 0, tentouEm: 0 };
      const situacao = await sessaoDoSite(site);
      const estado = { ...antes, situacao, vistoEm: agora };
      if (situacao === 'travada') {
        if (agora - (antes.recarregouEm ?? 0) >= INTERVALO_F5_MS) {
          estado.recarregouEm = agora;
          const [aba] = await chrome.tabs.query({ url: site.abas });
          if (aba) await chrome.tabs.reload(aba.id);
          await registrar(site.fornecedor, 'recarregou', 'a página parou de falar com o servidor ("reconectando"): F5');
        }
      } else if (situacao === 'ok') {
        if (antes.situacao === 'login') await registrar(site.fornecedor, 'voltou', 'logado de novo');
        Object.assign(estado, { falhas: 0, avisado: false });
        chrome.notifications?.clear(`relogin-${site.fornecedor}`);
      } else if (situacao === 'login') {
        if (antes.situacao !== 'login') await registrar(site.fornecedor, 'caiu', 'a aba está na tela de login');
        const motivo = SEM_AUTOMATICO[site.fornecedor];
        const podeTentar = !motivo && estado.falhas < MAXIMO_FALHAS && agora - estado.tentouEm >= INTERVALO_TENTATIVA_MS;
        if (podeTentar) {
          estado.tentouEm = agora;
          let r;
          try {
            r = await naFrente(site, () => relogar(site));
          } catch (e) {
            r = { resultado: 'falhou', detalhe: e.message };
          }
          await registrar(site.fornecedor, r.resultado, r.detalhe);
          if (r.resultado === 'relogou' || r.resultado === 'ja-logado') Object.assign(estado, { situacao: 'ok', falhas: 0 });
          else if (r.resultado === 'falhou') estado.falhas++;
        }
        const desistiu = !!motivo || estado.falhas >= MAXIMO_FALHAS;
        if (estado.situacao === 'login' && desistiu && !estado.avisado) {
          avisar(site, motivo
            ? `A sessão caiu e o site ${motivo}. Clique aqui para abrir a aba.`
            : 'A extensão tentou entrar 2 vezes e não conseguiu. Clique aqui para abrir a aba.');
          estado.avisado = true;
        }
      }
      sessoes[site.fornecedor] = estado;
    }
    await chrome.storage.local.set({ sessoes });
    return sessoes;
  };

  /** Entrou à mão pelo painel: zera as falhas para o automático voltar a tentar */
  const zerarFalhas = async (fornecedor) => {
    const { sessoes = {} } = await chrome.storage.local.get('sessoes');
    if (sessoes[fornecedor]) sessoes[fornecedor] = { ...sessoes[fornecedor], falhas: 0, tentouEm: 0, avisado: false };
    await chrome.storage.local.set({ sessoes });
  };

  globalThis.Relogin = {
    telaDeLogin, passoDepois, ehOBotaoDeEntrar, paginaTravada, verificacaoPronta, relogar, registrar, sessaoDoSite, vigiar, zerarFalhas, relogando, naFrente,
    DEPOIS_DO_ENTRAR, SEM_AUTOMATICO, INTERVALO_TENTATIVA_MS,
    _pausa: (ms) => (pausa = ms),
  };
})();
