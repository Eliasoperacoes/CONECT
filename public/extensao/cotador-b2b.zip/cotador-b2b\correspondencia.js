/**
 * Achar um código de peça dentro de um texto qualquer (JSON, HTML, texto).
 *
 * Script comum, sem import/export: roda igual no content script da
 * extensão, na página injetada e nos testes (que só leem o globalThis).
 */
(() => {
  const SEPARADORES = '[\\s.\\-/]?';
  const TAMANHO_MINIMO = 3;

  /** "hg-51.70" → "HG5170" */
  const normalizar = (s) => String(s).toUpperCase().replace(/[^A-Z0-9]/g, '');

  /**
   * Expressão que aceita o código com ou sem separadores entre os caracteres
   * ("HG5170", "HG 5170", "HG-5170") e exige que ele não esteja colado a
   * outra letra ou número: "HG51700" é outra peça.
   */
  const padrao = (codigo) => {
    const chars = normalizar(codigo).split('').map((c) => c.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    return new RegExp(`(?<![A-Z0-9])${chars.join(SEPARADORES)}(?![A-Z0-9])`, 'gi');
  };

  /**
   * Devolve null se o código não aparece; senão, o total de ocorrências e
   * até `maximo` trechos de contexto ao redor delas.
   */
  const encontrar = (texto, codigo, maximo = 5) => {
    if (!texto || normalizar(codigo).length < TAMANHO_MINIMO) return null;
    const trechos = [];
    let total = 0;
    for (const m of String(texto).matchAll(padrao(codigo))) {
      total++;
      if (trechos.length < maximo) {
        const ini = Math.max(0, m.index - 80);
        trechos.push(String(texto).slice(ini, m.index + m[0].length + 80));
      }
    }
    return total ? { total, trechos } : null;
  };

  // Chaves que costumam guardar o identificador interno da peça no site
  const CHAVE_ID = /(^|_)id$|^id_|objectid|wsid|interno/i;
  const TAMANHO_MINIMO_ID = 6;

  /**
   * O site costuma buscar preço e estoque pelo id interno da peça, sem citar
   * o código. Aqui se acham, num JSON, os objetos que trazem o código (direto
   * ou num campo filho como {v: "OC90"}) e se devolvem os ids deles.
   */
  const idsDaPeca = (texto, codigo) => {
    let raiz;
    try { raiz = JSON.parse(texto); } catch { return []; }
    const alvo = normalizar(codigo);
    const ehCodigo = (v) => typeof v === 'string' && normalizar(v) === alvo;
    const ids = new Set();
    const visitar = (no) => {
      if (Array.isArray(no)) return no.forEach(visitar);
      if (!no || typeof no !== 'object') return;
      const valores = Object.values(no);
      const temCodigo = valores.some((v) => ehCodigo(v) || (v && typeof v === 'object' && !Array.isArray(v) && Object.values(v).some(ehCodigo)));
      if (temCodigo) {
        for (const [k, v] of Object.entries(no)) {
          if (!CHAVE_ID.test(k) || (typeof v !== 'string' && typeof v !== 'number')) continue;
          const s = String(v);
          if (normalizar(s).length >= TAMANHO_MINIMO_ID && !ehCodigo(s)) ids.add(s);
        }
      }
      valores.forEach(visitar);
    };
    visitar(raiz);
    return [...ids];
  };

  globalThis.Correspondencia = { normalizar, padrao, encontrar, idsDaPeca };
})();
