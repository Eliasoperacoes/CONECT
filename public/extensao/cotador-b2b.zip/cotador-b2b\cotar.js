/**
 * Painel lateral, parte "Cotar": desenha o que cotacao.js trouxe dos sites.
 */
(() => {
  const $ = (id) => document.getElementById(id);
  const brl = (v) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  const linha = (texto, classe) => {
    const el = document.createElement('div');
    if (classe) el.className = classe;
    el.textContent = texto;
    return el;
  };

  // Só textContent: dado do site não é confiável
  const qtd = (o) => (o.quantidade == null ? '' : ` · ${o.quantidade} un.`);
  const resumoOferta = ({ oferta: o, situacao, prazo }) =>
    `${brl(o.preco)} · ${o.local}${qtd(o)} · ${prazo}${situacao === 'FORA DO ESTADO' ? ' · FORA DO ESTADO' : ''}`;

  const desenharSimilares = (bloco, { modo, similares, erroSimilares }) => {
    if (erroSimilares) return bloco.append(linha(`Similares: ${erroSimilares}`, 'estado erro'));
    if (!similares) return;
    const lista = Escolha.similaresParaMostrar(similares, modo);
    const titulo = modo === 'auto' ? 'Similares com estoque em SP' : 'Similares';
    bloco.append(linha(lista.length ? `${titulo} (${lista.length})` : `${titulo}: nenhum`, 'subtitulo'));
    for (const s of lista)
      bloco.append(linha(`${s.peca.codigo} ${s.peca.marca ?? ''} · ${resumoOferta(s.escolha)}`, s.escolha.situacao === 'SP' ? 'similar' : 'similar fora'));
  };

  // Os passos do leitor (Lucios), para saber onde a peça se perdeu
  const desenharRastro = (bloco, rastro) => {
    if (!rastro?.length) return;
    const det = document.createElement('details');
    const resumo = document.createElement('summary');
    resumo.textContent = 'o que o leitor fez';
    det.append(resumo, ...rastro.map((p) => linha(p, 'meta')));
    bloco.append(det);
  };

  // Só textContent: dado do site não é confiável
  const desenhar = (r) => {
    const { site, erro, peca, ofertas, escolha } = r;
    const bloco = document.createElement('div');
    bloco.className = 'cotacao';
    bloco.append(linha(site.nome, 'fornecedor'));
    if (erro) return bloco.append(linha(erro, 'estado erro')), desenharRastro(bloco, r.rastro), bloco;
    // Sem a peça, o site ainda pode ter equivalentes (Barros: peça inativa)
    if (!peca) return bloco.append(linha('Não tem esta peça.', 'meta')), desenharRastro(bloco, r.rastro), desenharSimilares(bloco, r), bloco;
    bloco.append(linha(`${peca.codigo} · ${peca.marca ?? ''} · ${peca.descricao ?? ''}`, 'meta'));
    if (!escolha.oferta) {
      bloco.append(linha('Sem estoque em nenhum CD.', 'estado erro'));
    } else {
      const o = escolha.oferta;
      bloco.append(linha(resumoOferta(escolha), escolha.situacao === 'SP' ? 'melhor' : 'melhor fora'));
      const outros = ofertas.filter((x) => x.disponivel && x !== o).sort((a, b) => a.preco - b.preco);
      if (outros.length) {
        const det = document.createElement('details');
        const resumo = document.createElement('summary');
        resumo.textContent = `outros CDs com estoque (${outros.length})`;
        det.append(resumo, ...outros.map((x) => linha(`${brl(x.preco)} · ${x.local}${x.emSP ? '' : ' (fora de SP)'}${qtd(x)}`, 'meta')));
        bloco.append(det);
      }
    }
    desenharSimilares(bloco, r);
    return bloco;
  };


  const cotar = async () => {
    const codigo = $('cotar-codigo').value.trim();
    if (Correspondencia.normalizar(codigo).length < 3) return ($('cotar-estado').textContent = 'Digite um código com 3 ou mais caracteres.');
    const modo = $('incluir-similares').checked ? 'sim' : 'auto';
    $('cotar-estado').textContent = 'Consultando…';
    $('cotacoes').replaceChildren();
    const inicio = performance.now();
    const resultados = await Cotacao.cotarTodos(codigo, modo, { comEmTeste: true });
    $('cotacoes').replaceChildren(...Escolha.ordenarFornecedores(resultados).map(desenhar));
    $('cotar-estado').textContent = `Pronto em ${((performance.now() - inicio) / 1000).toFixed(1)} s.`;
  };

  $('cotar').addEventListener('click', () => cotar().catch((e) => ($('cotar-estado').textContent = e.message)));
  $('cotar-codigo').addEventListener('keydown', (e) => e.key === 'Enter' && $('cotar').click());
})();
