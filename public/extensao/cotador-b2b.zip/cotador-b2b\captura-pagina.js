/**
 * Roda no MUNDO DA PÁGINA (world: MAIN), não no da extensão.
 *
 * Embrulha fetch e XMLHttpRequest para enxergar as respostas que o próprio
 * site recebe, dentro da sessão logada do usuário. Não filtra nada aqui:
 * manda toda resposta textual para a ponte (ponte.js), que tem acesso ao
 * código pesquisado e decide o que guardar.
 *
 * Também registra método, cabeçalhos e corpo da REQUISIÇÃO: é o que vai
 * permitir repetir a mesma chamada na fatia 2 (leitor por configuração).
 */
(() => {
  if (window.__cotadorCaptura) return;
  window.__cotadorCaptura = true;

  const LIMITE = 2_000_000; // respostas maiores que ~2 MB são ignoradas
  const textual = (tipo) => !tipo || /json|text|javascript|xml/i.test(tipo);
  // O que nunca sai da página (credencial, dados da conta): sem-conta.js,
  // carregado antes deste no mesmo mundo da página
  const { ocultar, limpar, limparUrl } = SemConta;
  // Proteção anti-robô da Cloudflare (Rufato): um pacote opaco que não é do
  // site e não serve ao leitor. Nem os rastreadores de anúncio e audiência:
  // não servem ao leitor e levam o código do usuário e o e-mail em hash
  // (Rolemar: Google Analytics com uid=, pixel do Facebook, RD Station)
  const RASTREADOR = /\/cdn-cgi\/|google-analytics\.com|analytics\.google\.com|googleadservices\.com|googletagmanager\.com|doubleclick\.net|google\.com\/(?:rmkt|ccm|pagead)\/|facebook\.(?:com|net)|rdstation\.com|\.run\.app\/events|clarity\.ms|hotjar\./i;
  const ignorar = (url) => RASTREADOR.test(String(url ?? ''));
  const enviar = (dados) =>
    !ignorar(dados.url) &&
    window.postMessage(
      { __cotador: 'resposta', ...dados, url: limparUrl(dados.url), corpo: limpar(dados.corpo), corpoRequisicao: limpar(dados.corpoRequisicao) },
      '*',
    );
  // Corpo da requisição como texto. FormData (Rolemar: ajax-busca,
  // ajax-produto-detalhe) vira campo=valor; arquivo não entra
  const comoTexto = (b) =>
    typeof b === 'string' ? b
      : b instanceof URLSearchParams ? b.toString()
        : typeof FormData !== 'undefined' && b instanceof FormData ? new URLSearchParams([...b].filter(([, v]) => typeof v === 'string')).toString()
          : null;

  const cabecalhosComoObjeto = (h) => {
    if (!h) return {};
    const pares = h instanceof Headers ? [...h.entries()] : Array.isArray(h) ? h : Object.entries(h);
    return Object.fromEntries(pares.map(([nome, valor]) => [nome, ocultar(nome, valor)]));
  };

  // --- fetch ---
  const fetchOriginal = window.fetch;
  window.fetch = async function (entrada, opcoes = {}) {
    const resposta = await fetchOriginal.apply(this, arguments);
    try {
      const tipo = resposta.headers.get('content-type') || '';
      if (textual(tipo)) {
        const pedido = entrada instanceof Request ? entrada : null;
        resposta
          .clone()
          .text()
          .then((corpo) => {
            if (corpo.length > LIMITE) return;
            enviar({
              origem: 'fetch',
              url: resposta.url || String(entrada),
              metodo: (opcoes.method || pedido?.method || 'GET').toUpperCase(),
              status: resposta.status,
              tipo,
              corpo,
              cabecalhos: cabecalhosComoObjeto(opcoes.headers || pedido?.headers),
              corpoRequisicao: comoTexto(opcoes.body),
            });
          })
          .catch(() => {});
      }
    } catch {
      /* nunca quebrar o site por causa da captura */
    }
    return resposta;
  };

  // --- XMLHttpRequest ---
  const abrir = XMLHttpRequest.prototype.open;
  const definirCabecalho = XMLHttpRequest.prototype.setRequestHeader;
  const enviarXhr = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (metodo, url) {
    this.__cotador = { metodo: String(metodo).toUpperCase(), url: String(url), cabecalhos: {} };
    return abrir.apply(this, arguments);
  };
  XMLHttpRequest.prototype.setRequestHeader = function (nome, valor) {
    if (this.__cotador) this.__cotador.cabecalhos[nome] = ocultar(nome, valor);
    return definirCabecalho.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function (corpoRequisicao) {
    const info = this.__cotador;
    if (info) {
      info.corpoRequisicao = comoTexto(corpoRequisicao);
      this.addEventListener('load', () => {
        try {
          const tipo = this.getResponseHeader('content-type') || '';
          if (!textual(tipo)) return;
          let corpo = null;
          if (this.responseType === '' || this.responseType === 'text') corpo = this.responseText;
          else if (this.responseType === 'json') corpo = JSON.stringify(this.response);
          if (!corpo || corpo.length > LIMITE) return;
          enviar({ origem: 'xhr', url: this.responseURL || info.url, status: this.status, tipo, corpo, ...info });
        } catch {
          /* idem */
        }
      });
    }
    return enviarXhr.apply(this, arguments);
  };

  // --- envio de formulário (página inteira) ---
  // Sites que buscam enviando o formulário e carregando outra página (Rufato,
  // WebDev): a resposta é a página nova ("Capturar a página inteira" nela);
  // aqui fica o pedido, com os campos que o leitor vai repetir
  const camposDoFormulario = (form, botao) => {
    const dados = new FormData(form);
    // Botão de imagem vai como nome.x / nome.y (o clique), como o navegador
    // manda; registrar "nome=" ensinou errado o leitor da Lucios (24/10/2026)
    if (botao?.name && String(botao.type).toLowerCase() === 'image') dados.append(`${botao.name}.x`, '0'), dados.append(`${botao.name}.y`, '0');
    else if (botao?.name) dados.append(botao.name, botao.value ?? '');
    return new URLSearchParams([...dados].filter(([, v]) => typeof v === 'string')).toString();
  };
  const registrarFormulario = (form, botao) => {
    try {
      enviar({
        origem: 'formulario', url: form.action || location.href, metodo: (form.method || 'GET').toUpperCase(),
        status: '—', tipo: 'application/x-www-form-urlencoded', corpo: '', cabecalhos: {},
        corpoRequisicao: camposDoFormulario(form, botao),
      });
    } catch {
      /* idem */
    }
  };
  if (typeof HTMLFormElement !== 'undefined') {
    const submeter = HTMLFormElement.prototype.submit;
    HTMLFormElement.prototype.submit = function () {
      registrarFormulario(this);
      return submeter.apply(this, arguments);
    };
    // Envio pelo botão ou Enter (o submit() acima não dispara este evento)
    window.addEventListener('submit', (e) => registrarFormulario(e.target, e.submitter), true);
  }
})();
