/**
 * Leitor da Furacão (ver docs/fornecedores/furacao.md).
 *
 * Uma chamada traz tudo: a busca (datatable do site) devolve a peça e as
 * equivalentes, cada uma com saldo e preço por unidade da Furacão. O botão
 * "Similar" só lista os códigos (REFX); preço e estoque vêm da busca.
 *
 * Quem chama passa:
 *   - buscar(caminho, { method, body }): fetch na aba logada, devolve o JSON
 *   - cliente, unidade: o que a própria página mandou na última busca (podem faltar)
 * O CNPJ do cliente nunca é guardado: vem da página, a cada cotação.
 * Depende de Correspondencia e LeitoresComum (leitores/comum.js).
 */
(() => {
  const FORNECEDOR = 'Furacão';
  const BUSCA = '/sav_api/laravel/public/api/busca_produto';
  const SIMILAR = '/vendas/sav/api/produtos/similar/';

  // Sigla da unidade → onde fica. Pelo B2B a Malachias compra só de Campinas;
  // Ribeirão (peça esgotada) é pelo WhatsApp, fora do leitor (Elias, 22/10/2026)
  const UNIDADES = {
    CPS: { nome: 'CAMPINAS', proximidade: 2 },
  };

  // As colunas que a tabela do site declara: o servidor monta a busca por elas
  const COLUNAS = [
    ['referencia', true, true], ['descricao', true, true], ['similar', true, false], ['numero_original', true, true],
    ['marca', true, true], ['desabreviado', true, true], ['codigo_barra', true, true], ['unidade', false, true],
    ['valor_dia', false, true], ['unidade.abreviatura', false, true], ['multiplo', false, true], ['multiplo', false, true],
    ['unidade_medida', false, true], ['codigo_barra', false, false],
  ];

  const corpoDaBusca = (termo, { cliente, unidade }) => {
    const datatable = {
      sEcho: 1, iColumns: COLUNAS.length,
      sColumns: 'referencia,descricao,similar,numeroOriginal,marca,desabreviado,codigoBarra,saldo,valorDia,unidade,multiplo,multiplo,unidadeMedida,codigoBarra',
      iDisplayStart: 0, iDisplayLength: 50,
    };
    COLUNAS.forEach(([dado, pesquisavel, ordenavel], i) =>
      Object.assign(datatable, { [`mDataProp_${i}`]: dado, [`sSearch_${i}`]: '', [`bRegex_${i}`]: false, [`bSearchable_${i}`]: pesquisavel, [`bSortable_${i}`]: ordenavel }));
    Object.assign(datatable, {
      iSortCol_0: 1, sSortDir_0: 'asc', sSearch: termo, bRegex: false, iSortingCols: 1, perfil: 'Cliente',
      pedido: null, pedido_unidade: null, pedido_unidade_abrev: null, pedido_unidade_apoio: null, pedido_unidade_apoio_abrev: null,
      cliente_unidade_principal: null, cliente_uf: null, cliente_cidade: null, cliente_atacado: null, cliente_simples_nacional: null,
      cliente_suframa: null, cliente_selecionado: cliente ?? null, unidade: unidade ?? '00', sSearchType_4: 'select', sSearchType: 'text',
    });
    return JSON.stringify({ datatable });
  };

  const norm = (s) => Correspondencia.normalizar(s ?? '');

  /** Item da busca → peça + uma oferta por unidade (filial) */
  const daBusca = (item) => {
    const peca = { referencia: item.referencia, codigo: item.referencia, descricao: item.descricao_fraga || item.descricao || null, marca: item.marca ?? null };
    const filiais = Object.values(item.filial ?? {});
    const ofertas = (filiais.length ? filiais : [item]).map((f) => {
      const sigla = f.unidade?.abreviatura ?? '';
      const lugar = UNIDADES[sigla] ?? { nome: sigla || 'FURACÃO', proximidade: null };
      const preco = Number(f.valor_dia) || 0;
      const quantidade = Number(f.saldo) || 0;
      return {
        fornecedor: FORNECEDOR, codigo: item.referencia, local: lugar.nome, emSP: (f.uf_origem ?? item.uf_origem) === 'SP',
        proximidade: lugar.proximidade, preco, quantidade, disponivel: quantidade > 0 && preco > 0,
      };
    });
    return { peca, ofertas };
  };

  /**
   * Qual item é a peça pedida: o código da Furacão (referencia) ou o de fábrica;
   * senão, "prefixo da marca + código" (VTR + B1799DDU), se só um bater.
   */
  const acharItem = (itens, codigo) => {
    const alvo = norm(codigo);
    const exato = itens.find((i) => norm(i.referencia) === alvo) ?? itens.find((i) => norm(i.codigo_fabrica) === alvo);
    if (exato) return exato;
    const comPrefixo = itens.filter((i) => /^[A-Z]{1,4}$/.test(norm(i.referencia).slice(0, -alvo.length)) && norm(i.referencia).endsWith(alvo));
    return comPrefixo.length === 1 ? comPrefixo[0] : null;
  };

  const lista = (r) => {
    if (!Array.isArray(r?.aaData)) throw new Error(`a busca não devolveu a lista de peças (veio: ${JSON.stringify(r)?.slice(0, 80) ?? 'nada'})`);
    return r.aaData;
  };

  // O que a busca já trouxe, para os similares não repetirem a chamada
  const visto = new Map();

  const ler = async (codigo, opcoes) => {
    const itens = lista(await opcoes.buscar(BUSCA, { method: 'POST', body: corpoDaBusca(codigo, opcoes) }));
    itens.forEach((i) => visto.set(norm(i.referencia), i));
    const item = acharItem(itens, codigo);
    return item ? daBusca(item) : { peca: null, ofertas: [] };
  };

  /** Similares: os códigos do botão "Similar"; preço e estoque da busca (ou de uma busca por código) */
  const similares = async (peca, opcoes) => {
    const refs = await opcoes.buscar(`${SIMILAR}${encodeURIComponent(peca.referencia)}`, { method: 'GET' });
    if (!Array.isArray(refs)) throw new Error('os similares não vieram');
    const fila = LeitoresComum.limitar(opcoes.buscar, 4);
    const achados = await Promise.all(
      refs.map(async ({ REFX }) => {
        if (!REFX || norm(REFX) === norm(peca.referencia)) return null;
        let item = visto.get(norm(REFX));
        if (!item) item = acharItem(lista(await fila(BUSCA, { method: 'POST', body: corpoDaBusca(REFX, opcoes) })), REFX);
        return item ? daBusca(item) : null;
      }),
    );
    return achados.filter(Boolean);
  };

  globalThis.Leitores = { ...globalThis.Leitores, furacao: { ler, similares, UNIDADES, corpoDaBusca } };
})();
