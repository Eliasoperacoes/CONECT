/**
 * Leitor da Sky Peças (ver docs/fornecedores/sky.md).
 *
 * Duas filiais, e a filial "ativa" fica na sessão do site (a aba de cima):
 * a busca traz preço e estoque só dela. As outras vêm do olho "E.F."
 * (outros_estoques), com preço e estoque. Por isso não se troca a filial:
 * isso mudaria a aba de quem estiver comprando no site.
 *
 * Quem chama passa:
 *   - buscar(caminho, { method, body }): fetch na aba logada, devolve o JSON
 *   - csrf: o token que a própria página usou na última busca (pode faltar)
 * Depende de Correspondencia, LeitoresComum (leitores/comum.js) e DOMParser.
 */
(() => {
  const FORNECEDOR = 'Sky Peças';

  // proximidade: 1 = mais perto de Pirassununga (desempate de preço)
  const FILIAIS = [
    { nome: 'PIRACICABA', padrao: /PIRA/i, emSP: true, proximidade: 1 },
    { nome: 'GUARULHOS', padrao: /GUARU/i, emSP: true, proximidade: 2 },
  ];

  /** "R$ 1.234,56" → 1234.56 */
  const valor = (texto = '') => Number(String(texto).replace(/[^\d,]/g, '').replace(',', '.')) || 0;
  /** "396" → 396; "indisponivel" → 0 */
  const unidades = (texto = '') => Number.parseInt(String(texto).trim(), 10) || 0;
  const texto = (el) => el?.textContent.trim() ?? '';
  const html = (h) => new DOMParser().parseFromString(h ?? '', 'text/html');

  // O que veio no lugar da lista, para o erro: os campos e um pedaço curto do texto
  const resumo = (r) =>
    r == null ? 'vazio' : typeof r !== 'object' ? String(r).slice(0, 80) : Object.entries(r).map(([k, v]) => `${k}: ${String(typeof v === 'object' ? JSON.stringify(v) : v).slice(0, 60)}`).join('; ').slice(0, 200) || 'vazio';

  const formulario = (campos, csrf) => new URLSearchParams({ ...campos, ...(csrf ? { csrf_token: csrf } : {}) }).toString();

  // O mesmo formulário que a busca do site manda, só com o código preenchido
  const corpoDaBusca = (codigo, csrf) =>
    formulario({
      montadora: '0', veiculo: '0', marca: '0', departamento: '0', produto: '0', modelo: '', motor: '0',
      valvula: '0', ano: '', codigo, peca: '', codigo_barras: '', codigos: '', tipo_clique_busca_peca: 'clique',
    }, csrf);

  /** HTML da busca → [{ nn, codigo, descricao, marca, preco, quantidade }] (preço e estoque da filial ativa) */
  const pecasDaBusca = (h) =>
    [...html(h).querySelectorAll('.bx_produto')].map((bx) => {
      const estoque = bx.querySelector('.lkEstoqueProduto');
      return {
        nn: texto(bx.querySelector('.codnn')).replace(/^N\/N:\s*/i, ''),
        codigo: texto(bx.querySelector('.codfab strong')),
        descricao: texto(bx.querySelector('.nome')) || null,
        marca: texto(bx.querySelector('.fornecedor')) || null,
        preco: valor(texto(bx.querySelector('.preco_final'))),
        // O texto do link é "396 E.F." ou "indisponivel E.F."
        quantidade: estoque?.classList.contains('indisponivel') ? 0 : unidades(estoque?.firstChild?.textContent),
      };
    });

  /** HTML do E.F. → [{ loja, preco, quantidade }] das filiais que não são a ativa */
  const lojasDoEF = (h) =>
    [...html(h).querySelectorAll('.tbody .tr')].map((tr) => {
      const [loja, preco, estoque] = [...tr.querySelectorAll('.td')];
      return { loja: texto(loja), preco: valor(preco?.querySelector('.valor')?.getAttribute('title') ?? texto(preco)), quantidade: unidades(texto(estoque)) };
    });

  const oferta = (codigo, filial, preco, quantidade) => ({
    fornecedor: FORNECEDOR, codigo, local: filial.nome, emSP: filial.emSP, proximidade: filial.proximidade,
    preco, quantidade, disponivel: quantidade > 0 && preco > 0,
  });

  const filialDe = (loja) => FILIAIS.find((f) => f.padrao.test(loja)) ?? { nome: loja.toUpperCase(), emSP: true, proximidade: null };

  /**
   * Da peça como veio na lista (preço e estoque da filial ativa) às ofertas das
   * duas filiais: a ativa + o E.F. Se o E.F. falhar, a ativa ainda vale.
   */
  const ofertasDa = async ({ preco, quantidade, ...peca }, buscar, csrf) => {
    let outras = [];
    let erroOutras;
    try {
      const ef = await buscar(`/produtos/outros_estoques/${encodeURIComponent(peca.nn)}`, { method: 'POST', body: formulario({}, csrf) });
      outras = lojasDoEF(ef?.html);
    } catch (e) {
      erroOutras = e.message;
    }
    // A ativa é a filial conhecida que o E.F. não lista
    const restantes = FILIAIS.filter((f) => !outras.some((o) => f.padrao.test(o.loja)));
    const ativa = restantes.length === 1 ? restantes[0] : { nome: 'FILIAL ATIVA', emSP: true, proximidade: null };
    const ofertas = [oferta(peca.codigo, ativa, preco, quantidade), ...outras.map((o) => oferta(peca.codigo, filialDe(o.loja), o.preco, o.quantidade))];
    return erroOutras ? { peca, ofertas, erroOutras } : { peca, ofertas };
  };

  const ler = async (codigo, { buscar, csrf }) => {
    const r = await buscar('/site/buscar', { method: 'POST', body: corpoDaBusca(codigo, csrf) });
    // Busca sem resultado vem como erro do site: é "não tem a peça"
    if (r?.error && /não trouxe resultados/i.test(r.msg ?? '')) return { peca: null, ofertas: [] };
    // Sem a lista de peças não é "não tem a peça": é a busca que não funcionou
    if (typeof r?.html !== 'string') throw new Error(`a busca não devolveu a lista de peças (${resumo(r)})`);
    const alvo = Correspondencia.normalizar(codigo);
    const achada = pecasDaBusca(r.html).find((p) => Correspondencia.normalizar(p.codigo) === alvo);
    if (!achada) return { peca: null, ofertas: [] };
    return ofertasDa(achada, buscar, csrf);
  };

  /**
   * Similares: o modal "Similar" devolve os mesmos blocos da busca. Cada um
   * ganha o seu E.F. (no máximo 4 ao mesmo tempo: a OC90 tem 9 similares).
   */
  const similares = async (peca, { buscar, csrf }) => {
    const caminho = `/produtos/similar/${encodeURIComponent(peca.nn)}?${new URLSearchParams({ nome: peca.descricao ?? '', codfab: peca.codigo })}`;
    const r = await buscar(caminho, { method: 'POST', body: formulario({}, csrf) });
    if (typeof r?.html !== 'string') throw new Error(`os similares não vieram (${resumo(r)})`);
    const lista = pecasDaBusca(r.html).filter((p) => p.nn && p.nn !== peca.nn);
    const fila = LeitoresComum.limitar(buscar, 4);
    return Promise.all(lista.map((p) => ofertasDa(p, fila, csrf)));
  };

  globalThis.Leitores = { ...globalThis.Leitores, sky: { ler, similares, FILIAIS, pecasDaBusca, lojasDoEF } };
})();
