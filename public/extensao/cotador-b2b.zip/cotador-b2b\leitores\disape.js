/**
 * Leitor da Disape e da RMP (ver docs/fornecedores/disape.md e rmp.md): as
 * duas lojas são o mesmo Magento (FCamara), com os centros de distribuição da
 * RMP. Um leitor, dois sites.
 *
 * Duas chamadas:
 *   1. a página de resultado da busca (HTML já montado): a peça (SKU, código
 *      do fabricante, marca) e, na configuração do botão "Produtos Similares"
 *      (x-magento-init, `relatedProd`), a lista de similares;
 *   2. o preço e o estoque, por lista de SKUs, na filial da sessão
 *      (`/preco/index/priceajax`), como o próprio site faz.
 *
 * A filial (centro de distribuição) é a escolhida no topo do site, guardada
 * na sessão; ela muda preço e estoque. O leitor pergunta qual é ao próprio
 * menu do topo (`/customer_menu/index/header`): a da RMP estava em Cariacica
 * (ES), fora de SP (24/10/2026).
 *
 * Quem chama passa:
 *   - texto(caminho): GET na aba logada, devolve o HTML
 *   - json(caminho, corpo): sem corpo GET, com corpo POST; devolve o JSON
 * Depende de Correspondencia e DOMParser.
 */
(() => {
  const norm = (s) => Correspondencia.normalizar(s ?? '');
  const texto = (el) => el?.textContent.trim() ?? '';

  /** O HTML da busca → peças { id, sku, codigo, marca, descricao } */
  const pecasDaBusca = (doc) =>
    [...doc.querySelectorAll('li[id^="product-item-"]')].map((li) => ({
      id: li.querySelector('[id^="product-item-info_"]')?.id.replace('product-item-info_', '') ?? null,
      sku: li.id.replace('product-item-', ''),
      codigo: texto(li.querySelector('.cod-fabricante span')),
      marca: texto(li.querySelector('.fabricante span')) || null,
      descricao: texto(li.querySelector('.product-item-link')) || null,
    }));

  /**
   * Os similares de cada peça, como o botão do site os recebe: em algum ponto
   * dos x-magento-init há `relatedProd: { <id da peça>: { ...: { sku, ... } } }`.
   */
  const similaresDaPagina = (doc) => {
    const porPeca = {};
    const visitar = (no) => {
      if (!no || typeof no !== 'object') return;
      if (no.relatedProd && typeof no.relatedProd === 'object')
        for (const [id, itens] of Object.entries(no.relatedProd)) porPeca[id] = Object.values(itens ?? {});
      Object.values(no).forEach(visitar);
    };
    for (const s of doc.querySelectorAll('script[type="text/x-magento-init"]')) {
      try { visitar(JSON.parse(s.textContent)); } catch { /* bloco que não é JSON */ }
    }
    return porPeca;
  };

  /** "40 - RMP-ES(AG)" + "CARIACICA/ES" → { codigo: '40', local: 'CARIACICA/ES', emSP: false } */
  const filialDoMenu = (menu) => {
    const codigo = String(menu?.cdAtual ?? '').match(/^\s*(\d+)/)?.[1] ?? null;
    const local = String(menu?.nomeFilialAtual ?? '').trim();
    return codigo && local ? { codigo, local, emSP: /\/SP$/i.test(local) } : null;
  };

  // A filial do menu, lembrada (por site) enquanto o código dela for o do preço
  const filialDaSessao = async (json, codigoDoPreco, memoria) => {
    if (memoria.filial && memoria.filial.codigo === String(codigoDoPreco)) return memoria.filial;
    try {
      memoria.filial = filialDoMenu(await json('/customer_menu/index/header'));
    } catch {
      memoria.filial = null;
    }
    return memoria.filial;
  };

  /** Preço e estoque de uma lista de SKUs na filial da sessão */
  const precos = async (json, skus, memoria) => {
    if (!skus.length) return { filial: null, porSku: {} };
    const r = await json('/preco/index/priceajax', JSON.stringify({ skus, prices: skus.map(() => null) }));
    const lista = r?.result?.estoquesPrecoFlexibilizado;
    if (!Array.isArray(lista)) throw new Error(`o preço não veio (veio: ${JSON.stringify(r)?.slice(0, 80) ?? 'nada'})`);
    // Sem o menu, fica como antes: o nome da filial do preço e SP
    const menu = await filialDaSessao(json, r.result.codigoFilial, memoria);
    const filial = menu ?? { local: r.result.nomeFilial || null, emSP: true };
    return { filial, porSku: Object.fromEntries(lista.map((p) => [p.sku, p])) };
  };

  // Preço = o "Preço" da tela (precoFlexibilizado), não o "Preço Final" com
  // imposto (Elias, 23/10/2026). Uma filial só, a da sessão
  const oferta = (FORNECEDOR, peca, p, filial) => {
    const preco = Number(p?.precoFlexibilizado) || 0;
    const quantidade = Number(p?.quantidadeDisponivelEstoque) || 0;
    return {
      fornecedor: FORNECEDOR, codigo: peca.codigo, local: filial.local || FORNECEDOR.toUpperCase(), emSP: filial.emSP, proximidade: null,
      preco, quantidade, disponivel: p?.disponivelVenda === 'S' && quantidade > 0 && preco > 0,
    };
  };

  const criar = (FORNECEDOR) => {
    // O que a busca trouxe, para os similares não repetirem a página
    let ultima = null;
    const memoria = { filial: null };

    const ler = async (codigo, { texto: pegarTexto, json }) => {
      const caminho = `/catalogsearch/result/?${new URLSearchParams({ q: codigo, code: codigo })}`;
      const doc = new DOMParser().parseFromString(await pegarTexto(caminho), 'text/html');
      const alvo = norm(codigo);
      const peca = pecasDaBusca(doc).find((p) => norm(p.codigo) === alvo);
      ultima = { doc, peca };
      if (!peca) return { peca: null, ofertas: [] };
      const { filial, porSku } = await precos(json, [peca.sku], memoria);
      return { peca, ofertas: [oferta(FORNECEDOR, peca, porSku[peca.sku], filial)] };
    };

    /** Similares: a lista do botão do site (já veio na busca) + o preço deles numa chamada */
    const similares = async (peca, { json }) => {
      if (ultima?.peca !== peca) throw new Error('a busca da peça não está na memória');
      const itens = (similaresDaPagina(ultima.doc)[peca.id] ?? []).filter((i) => i.sku && i.sku !== peca.sku);
      const { filial, porSku } = await precos(json, itens.map((i) => i.sku), memoria);
      return itens.map((i) => {
        const sim = { id: String(i.productId ?? ''), sku: i.sku, codigo: i.codFabricanteValue ?? i.codFabricante ?? '', marca: i.fabricanteValue ?? i.fabricante ?? null, descricao: i.name ?? null };
        return { peca: sim, ofertas: [oferta(FORNECEDOR, sim, porSku[i.sku], filial)] };
      });
    };

    return { ler, similares, pecasDaBusca, similaresDaPagina, filialDoMenu };
  };

  globalThis.Leitores = { ...globalThis.Leitores, disape: criar('Disape'), rmp: criar('Real') };
})();
