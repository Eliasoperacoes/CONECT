/**
 * Leitor da Haifer (ver docs/fornecedores/haifer.md).
 *
 * O site é Blazor Server: a tela conversa com o servidor por SignalR, num
 * protocolo binário, sem fetch/XHR que dê para repetir. Então o leitor USA A
 * TELA, como o vendedor: escreve o código na Busca, aperta Enter, espera a
 * grade redesenhar e lê as linhas do DOM.
 *
 * Cada linha: Cód.Fabricante, Descrição, Marca e até dois botões de preço:
 * o normal (verde) e o de promoção (vermelho, `btn-danger`). Botão com a
 * classe `indisponivel` = sem estoque (Elias, 24/10/2026). Quantidade não
 * aparece: fica null (a escolha trata como "só sim/não").
 *
 * A busca também traz equivalentes de outras marcas (PSL619 → WEGA WO130):
 * a linha do código é a peça; as outras são os similares.
 *
 * Quem chama passa { documento, esperar, rastro } (cotacao.js, tipo tela).
 * Depende de Correspondencia.
 */
(() => {
  const FORNECEDOR = 'Haifer';
  const ESPERA = 15000; // a grade tem até isso para redesenhar
  const SOSSEGO = 400; // com a peça na grade, quieta por isso antes de ler
  const REPETIDA = 2500; // mesma busca de antes: a grade não muda; lê depois disso
  const VAZIA = 1500; // "No data to display" e quieta por isso: não tem
  const QUIETA = 3000; // mudou, sem a peça, quieta por isso: só equivalentes
  const norm = (s) => Correspondencia.normalizar(s ?? '');
  const reais = (t) => {
    const m = String(t ?? '').match(/(\d{1,3}(?:\.\d{3})*|\d+),(\d{2})/);
    return m ? Number(`${m[1].replace(/\./g, '')}.${m[2]}`) : null;
  };

  // A grade da busca (a do carrinho fica na outra coluna)
  const gradeDaBusca = (doc) => doc.querySelector('.pesquisa dxbl-grid');
  const campoDaBusca = (doc) => doc.querySelector('.pesquisa .busca input, .busca input.dxbl-text-edit-input');

  /** "Cód.Fabricante: PSL619" → "PSL619" (o rótulo e o valor em spans separados) */
  const campo = (linha, rotulo) => {
    const span = [...linha.querySelectorAll('.info-descr span')].find((s) => s.textContent.trim().toLowerCase().startsWith(rotulo));
    return span?.nextElementSibling?.textContent.trim() || null;
  };

  /** As linhas da grade: código, descrição, marca, preço normal, promoção, disponível */
  const lerLinhas = (doc) =>
    [...(gradeDaBusca(doc)?.querySelectorAll('tr[data-visible-index]') ?? [])].map((tr) => {
      const botoes = [...tr.querySelectorAll('.info-right button.btn-preco')];
      const promocao = botoes.find((b) => /(^|\s)dxbl-btn-danger(\s|$)/.test(b.getAttribute('class') ?? ''));
      const normal = botoes.find((b) => b !== promocao);
      return {
        codigo: campo(tr, 'cód.fabricante'),
        descricao: campo(tr, 'descrição'),
        marca: campo(tr, 'marca'),
        normal: reais(normal?.querySelector('.info-preco')?.textContent),
        promocao: reais(promocao?.querySelector('.info-preco')?.textContent),
        disponivel: !!normal && !normal.classList.contains('indisponivel'),
      };
    }).filter((l) => l.codigo);

  const paraResultado = (l) => {
    const preco = l.promocao > 0 && !(l.normal > 0 && l.normal <= l.promocao) ? l.promocao : l.normal;
    return {
      peca: { codigo: l.codigo, marca: l.marca, descricao: l.descricao },
      ofertas: [{
        fornecedor: FORNECEDOR, codigo: l.codigo, local: 'Haifer', emSP: true, proximidade: null,
        preco, quantidade: null, disponivel: l.disponivel && preco > 0,
      }],
    };
  };

  /**
   * Escreve na Busca e aperta Enter, como o vendedor; espera a grade.
   * Devolve como terminou, para o rastro do painel.
   */
  const buscar = async (codigo, { documento: doc, esperar }) => {
    const campoBusca = campoDaBusca(doc);
    if (!campoBusca) throw new Error('a tela "Pedido On-line" não está aberta (sem o campo Busca)');
    const alvo = norm(codigo);
    // A grade como está agora; ela muda quando a Blazor redesenha
    const retrato = () => gradeDaBusca(doc)?.innerHTML ?? '';
    let anterior = retrato();
    campoBusca.focus?.();
    campoBusca.value = codigo;
    // Os eventos da própria janela da página (no Chrome, a aba; nos testes, a de mentira)
    const janela = doc.defaultView ?? globalThis;
    campoBusca.dispatchEvent(new janela.Event('input', { bubbles: true }));
    campoBusca.dispatchEvent(new janela.Event('change', { bubbles: true }));
    // O texto vai ao servidor antes do Enter: com Enter logo em seguida a
    // busca rodava com o texto ANTERIOR, e a peça só vinha na cotação seguinte
    // (24/10/2026). O editor mostra em "field-text" o que o servidor recebeu
    const editor = campoBusca.closest?.('dxbl-input-editor');
    let recebeu = !editor;
    for (let i = 0; !recebeu && i < 30; i++) {
      if (norm(editor.getAttribute('field-text')) === alvo) recebeu = true;
      else await esperar(100);
    }
    const tecla = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
    for (const tipo of ['keydown', 'keypress', 'keyup'])
      campoBusca.dispatchEvent(typeof janela.KeyboardEvent === 'function'
        ? new janela.KeyboardEvent(tipo, tecla)
        : Object.assign(new janela.Event(tipo, tecla), { key: 'Enter', code: 'Enter', keyCode: 13, which: 13 }));
    // Pronta quando: a peça aparece; ou "No data to display" e a grade parou;
    // ou a grade mudou e ficou parada por um bom tempo (só equivalentes). Não
    // basta "mudou e parou um instante": a Haifer pode limpar a grade antes
    // de trazer o resultado, e o leitor lia a grade vazia no meio do caminho
    const temCodigo = () => lerLinhas(doc).some((l) => norm(l.codigo) === alvo);
    const semDados = () => !!gradeDaBusca(doc)?.querySelector('.dxbl-grid-empty-data-not-found');
    const texto = recebeu ? 'o servidor recebeu o texto' : 'o servidor não confirmou o texto';
    let mexeu = false;
    let ultima = Date.now();
    const inicio = Date.now();
    while (Date.now() - inicio < ESPERA) {
      await esperar(100);
      const agora = retrato();
      if (agora !== anterior) { mexeu = true; ultima = Date.now(); anterior = agora; continue; }
      const parada = Date.now() - ultima;
      // O mesmo código de novo (a estação repete muito): a grade já mostra a
      // peça e não vai mudar; lê depois de um tempo curto
      if (temCodigo() && (mexeu ? parada >= SOSSEGO : Date.now() - inicio >= REPETIDA)) return `${texto}; ${mexeu ? 'a grade trouxe a peça' : 'a grade já mostrava a peça'}`;
      if (mexeu && semDados() && parada >= VAZIA) return `${texto}; a grade voltou sem dados`;
      if (mexeu && parada >= QUIETA) return `${texto}; a grade mudou e parou sem a peça`;
    }
    return `${texto}; a grade ${mexeu ? 'mudou mas não parou' : 'não mudou'} em ${ESPERA / 1000} s`;
  };

  // O que a busca trouxe além da peça, para os similares não repetirem a busca
  let ultima = { codigo: null, outras: [] };

  const ler = async (codigo, opcoes) => {
    const { documento: doc, rastro = [] } = opcoes;
    const alvo = norm(codigo);
    const comoTerminou = await buscar(codigo, opcoes);
    const linhas = lerLinhas(doc);
    const achada = linhas.find((l) => norm(l.codigo) === alvo);
    rastro.push(`busca ${codigo}: ${comoTerminou}; ${linhas.length} linhas, ${achada ? `achou ${achada.codigo} ${achada.marca ?? ''}` : 'nenhuma com o código'}`);
    ultima = { codigo: alvo, outras: linhas.filter((l) => l !== achada) };
    if (!achada) {
      // Sem a peça, os equivalentes que a busca trouxe ainda servem (como a Barros)
      const similares = ultima.outras.map(paraResultado);
      return similares.length ? { peca: null, ofertas: [], similares } : { peca: null, ofertas: [] };
    }
    return paraResultado(achada);
  };

  /** Os equivalentes que vieram na mesma busca (outras marcas) */
  const similares = async (peca) => (norm(peca.codigo) === ultima.codigo ? ultima.outras : []).map(paraResultado);

  globalThis.Leitores = { ...globalThis.Leitores, haifer: { ler, similares, lerLinhas, ESPERA } };
})();
