/**
 * Roda no mundo da EXTENSÃO dentro da página (content script isolado).
 *
 * Recebe as respostas do captura-pagina.js e só repassa ao serviço as que
 * contêm o código gravado ou um id interno da peça já descoberto (o preço
 * costuma vir por id, sem citar o código). Depende de correspondencia.js,
 * carregado antes no mesmo content script.
 */
(() => {
  if (window.__cotadorPonte) return;
  window.__cotadorPonte = true;

  let gravacao;
  const pendentes = [];

  /** Onde procurar: a resposta e, se ela não cita a peça, a própria chamada (endereço e corpo) */
  const procurar = (dados, termo) =>
    Correspondencia.encontrar(dados.corpo, termo) ?? Correspondencia.encontrar(`${dados.url ?? ''}\n${dados.corpoRequisicao ?? ''}`, termo);

  const avaliar = (dados) => {
    if (!gravacao?.codigo) return;
    let achado = procurar(dados, gravacao.codigo);
    let termo = gravacao.codigo;
    if (achado) {
      const ids = Correspondencia.idsDaPeca(dados.corpo, gravacao.codigo);
      if (ids.length) chrome.runtime.sendMessage({ tipo: 'ids', ids });
    } else {
      for (const id of gravacao.ids ?? []) {
        achado = procurar(dados, id);
        if (achado) { termo = id; break; }
      }
    }
    // "Gravar tudo": para a descoberta de um site novo (trocar filial, abrir
    // estoque das filiais), em que a chamada não cita peça nenhuma
    if (!achado && gravacao.tudo) { achado = { total: 0, trechos: [] }; termo = '(tudo)'; }
    if (!achado) return;
    chrome.runtime.sendMessage({
      tipo: 'captura',
      dados: { ...dados, termo, trechos: achado.trechos, ocorrencias: achado.total, pagina: location.href, quando: Date.now() },
    });
  };

  // A leitura do storage é assíncrona: respostas que chegarem antes dela
  // esperam na fila em vez de se perderem
  chrome.storage.local.get('gravacao').then(({ gravacao: g }) => {
    gravacao = g;
    pendentes.splice(0).forEach(avaliar);
  });
  chrome.storage.onChanged.addListener((mudancas) => {
    if (mudancas.gravacao) gravacao = mudancas.gravacao.newValue;
  });

  window.addEventListener('message', (e) => {
    if (e.source !== window || e.data?.__cotador !== 'resposta') return;
    if (gravacao === undefined) pendentes.push(e.data);
    else avaliar(e.data);
  });
})();
