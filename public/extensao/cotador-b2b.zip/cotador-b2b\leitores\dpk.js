/**
 * Leitor da DPK (ver docs/fornecedores/dpk.md).
 *
 * Não guarda chave nem sessão: quem chama passa `buscar(url)`, que na
 * extensão é o fetch da própria página logada (com a chave dela).
 * Depende de Correspondencia (correspondencia.js) e LeitoresComum (leitores/comum.js).
 */
(() => {
  const API = 'https://api.dpk.com.br';
  const CD_DA_BUSCA = 1; // CAMPINAS, o padrão do seletor "Depósito"

  // StoreCode → CD, na ordem do modal "Ver + estoques".
  // proximidade: 1 = mais perto de Pirassununga (desempate de preço)
  const CDS = [
    { storeCode: 1, nome: 'CAMPINAS', emSP: true, proximidade: 2 },
    { storeCode: 40, nome: 'AUTOZ CPS', emSP: true, proximidade: 2 },
    { storeCode: 7, nome: 'BH', emSP: false },
    { storeCode: 4, nome: 'GOIANIA', emSP: false },
    { storeCode: 34, nome: 'HUB CACHOE', emSP: false },
    { storeCode: 24, nome: 'HUB CPS', emSP: true, proximidade: 2 },
    { storeCode: 33, nome: 'HUB ITAJAI', emSP: false },
    { storeCode: 37, nome: 'HUB R PRET', emSP: true, proximidade: 1 },
    { storeCode: 35, nome: 'HUB UBERLA', emSP: false },
    { storeCode: 41, nome: 'HUB VIANA', emSP: false },
    { storeCode: 32, nome: 'LIMOEIRO', emSP: false },
    { storeCode: 23, nome: 'P ALEGRE', emSP: false },
    { storeCode: 20, nome: 'P PRUDENTE', emSP: true, proximidade: 3 },
    { storeCode: 15, nome: 'RIB PRETO', emSP: true, proximidade: 1 },
    { storeCode: 21, nome: 'VIANA', emSP: false },
  ];

  const acharPeca = async (codigo, buscar) => {
    const url = `${API}/api-product/api/productSearch?Query=${encodeURIComponent(codigo)}&StoreCode=${CD_DA_BUSCA}`;
    const { products = [] } = (await buscar(url)) ?? {};
    const alvo = Correspondencia.normalizar(codigo);
    const p = products.find((x) => Correspondencia.normalizar(x.code) === alvo);
    return p && { id: p.id, sapCode: String(p.sapCode), codigo: p.code, descricao: p.description, marca: p.manufacturer ?? null };
  };

  const ofertaDoCD = async (peca, cd, buscar) => {
    const base = { fornecedor: 'DPK', codigo: peca.codigo, local: cd.nome, emSP: cd.emSP, proximidade: cd.proximidade ?? null };
    try {
      const url = `${API}/dpk-price/api/price/dpk?StoreCode=${cd.storeCode}&Item=${peca.sapCode}`;
      const [r = {}] = (await buscar(url)) ?? [];
      const quantidade = Number(r.stock) || 0;
      // O site às vezes diz "Disponível" com 0 unidades; vale a quantidade.
      // E preço zero é peça sem preço (WEGA WO130, 20/10): não dá para comprar
      const preco = Number(r.price) || 0;
      return { ...base, preco, quantidade, disponivel: quantidade > 0 && preco > 0 };
    } catch (e) {
      return { ...base, preco: 0, quantidade: 0, disponivel: false, erro: e.message };
    }
  };

  const ofertasNos = (peca, cds, buscar) => Promise.all(cds.map((cd) => ofertaDoCD(peca, cd, buscar)));

  const ler = async (codigo, { buscar }) => {
    const peca = await acharPeca(codigo, buscar);
    if (!peca) return { peca: null, ofertas: [] };
    return { peca, ofertas: await ofertasNos(peca, CDS, buscar) };
  };


  // "FILTRO OLEO LUBRIFICANTE - W7122 MANN" → "W7122" (quando não vem o detalhe)
  const codigoDaDescricao = (d = '') => d.split(' - ').pop().trim().split(/\s+/)[0] ?? '';

  /**
   * Similares da peça: lista equivalent[] da ficha. Só os vendidos (com
   * sapCode). Preço primeiro nos CDs de SP; fora de SP só se SP não tiver.
   */
  const similares = async (peca, { buscar }) => {
    const ficha = await buscar(`${API}/api-external/api/superk/productDetail/${CD_DA_BUSCA}/${peca.id}`);
    const lista = (ficha?.equivalent ?? []).filter((e) => e.sapCode && String(e.sapCode) !== peca.sapCode);
    const fila = LeitoresComum.limitar(buscar, 8);
    const cdsSP = CDS.filter((cd) => cd.emSP);
    const cdsFora = CDS.filter((cd) => !cd.emSP);
    return Promise.all(lista.map(async (e) => {
      const p = e.equivalentProductDetail?.product;
      const sim = {
        id: e.productId, sapCode: String(e.sapCode), codigo: p?.code ?? codigoDaDescricao(e.description),
        descricao: e.description ?? null, marca: p?.manufacturer ?? null,
      };
      let ofertas = await ofertasNos(sim, cdsSP, fila);
      if (!ofertas.some((o) => o.disponivel)) ofertas = ofertas.concat(await ofertasNos(sim, cdsFora, fila));
      return { peca: sim, ofertas };
    }));
  };

  globalThis.Leitores = { ...globalThis.Leitores, dpk: { ler, similares, CDS } };
})();
