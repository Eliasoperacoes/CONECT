/**
 * Leitor do Roles e da Pellegrino: mesma plataforma (grupo Comolatti), muda
 * só o endereço e o preço. Ver docs/fornecedores/roles.md e pellegrino.md.
 *
 * Quem chama passa:
 *   - buscar(url, { method, body }): fetch dentro da aba logada (cookie do site)
 *   - algolia: { origem, appId, apiKey }, a chave que a própria página usa
 * Depende de Correspondencia, LeitoresComum (leitores/comum.js) e DOMParser.
 */
(() => {
  const INDICE = 'b2b_prod';

  const codigoDoHit = (h) => h.codigo_fabricante_br?.v ?? h.codigo_fabricante ?? h.product_sku;

  const acharPeca = async (codigo, { buscar, algolia }) => {
    const url = `${algolia.origem}/1/indexes/*/queries?${chave(algolia)}`;
    const corpo = {
      requests: [{
        indexName: INDICE, query: codigo, hitsPerPage: 20,
        attributesToRetrieve: ['product_name', 'product_sku', 'brand_name', 'wsid', 'codigo_fabricante', 'codigo_fabricante_br'],
      }],
    };
    const r = await buscar(url, { method: 'POST', body: JSON.stringify(corpo) });
    const alvo = Correspondencia.normalizar(codigo);
    const hits = r?.results?.[0]?.hits ?? [];
    const h = hits.find((x) => x.wsid && Correspondencia.normalizar(codigoDoHit(x) ?? '') === alvo);
    return h && { wsid: h.wsid, codigo: codigoDoHit(h), descricao: h.product_name ?? null, marca: h.brand_name ?? null };
  };

  const primeiraLinha = (el) => el.textContent.split('\n').map((s) => s.trim()).find(Boolean) ?? '';

  /** HTML do pdpestoques → filiais: { id, nome, ordem, uf, disponivel } */
  const filiaisDoHtml = (html) => {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    return [...doc.querySelectorAll('.estoque-box[data-id]')].map((box) => {
      const comprar = box.querySelector('[id^="preco-comprar-"]');
      return {
        id: box.getAttribute('data-id'),
        nome: primeiraLinha(box),
        ordem: Number(box.getAttribute('data-order1')) || null,
        uf: comprar?.getAttribute('data-uf') ?? null,
        disponivel: !!comprar,
      };
    });
  };

  const chave = (algolia) =>
    `x-algolia-api-key=${encodeURIComponent(algolia.apiKey)}&x-algolia-application-id=${encodeURIComponent(algolia.appId)}`;

  /**
   * Ofertas de várias peças de uma vez: estoque de cada uma (pdpestoques) e
   * preço em lote, uma chamada por filial com todos os ids que ela tem.
   * Preço só de quem tem estoque: primeiro SP; fora de SP só se SP não tiver.
   */
  const ofertasDe = async (pecas, { buscar, origem, fornecedor }) => {
    const fila = LeitoresComum.limitar(buscar, 8);
    const filiaisPorPeca = await Promise.all(pecas.map(async (p) => {
      const { html = '' } = (await fila(`${origem}/catalogo/pdpestoques/${p.wsid}/1`)) ?? {};
      return filiaisDoHtml(html);
    }));

    const idsPorFilial = new Map(); // id da filial → wsids a precificar
    filiaisPorPeca.forEach((filiais, i) => {
      const disponiveis = filiais.filter((f) => f.disponivel);
      const emSP = disponiveis.filter((f) => f.uf === 'SP');
      for (const f of emSP.length ? emSP : disponiveis) {
        if (!idsPorFilial.has(f.id)) idsPorFilial.set(f.id, []);
        idsPorFilial.get(f.id).push(pecas[i].wsid);
      }
    });

    const precos = new Map(); // "filial|wsid" → preço
    const erros = new Map(); // filial → mensagem
    await Promise.all([...idsPorFilial].map(async ([local, ids]) => {
      try {
        const r = await fila(`${origem}/api/progress/b2b/produtos/precos?ids=${ids.join(',')}&local=${local}`);
        for (const p of r?.precos ?? []) precos.set(`${local}|${p.id}`, p.preco_com_imposto ?? 0);
      } catch (e) {
        erros.set(local, e.message);
      }
    }));

    return filiaisPorPeca.map((filiais, i) => filiais.map((f) => {
      const preco = precos.get(`${f.id}|${pecas[i].wsid}`) ?? 0;
      return {
        fornecedor,
        codigo: pecas[i].codigo,
        local: f.nome,
        emSP: f.uf === 'SP',
        preco,
        quantidade: null, // o site só diz disponível ou não
        disponivel: f.disponivel && preco > 0,
        proximidade: f.ordem,
        ...(erros.has(f.id) && { erro: erros.get(f.id) }),
      };
    }));
  };

  const ler = async (codigo, opcoes) => {
    const peca = await acharPeca(codigo, opcoes);
    if (!peca) return { peca: null, ofertas: [] };
    const [ofertas] = await ofertasDe([peca], opcoes);
    return { peca, ofertas };
  };

  // Vendidos pelo site = id de 16 letras (os outros são só referência)
  const VENDIDO = /^[A-Za-z]{16}$/;

  /** Similares da ficha do Algolia (similars[]), com as ofertas de cada um. */
  const similares = async (peca, opcoes) => {
    const { buscar, algolia } = opcoes;
    const ficha = await buscar(`${algolia.origem}/1/indexes/${INDICE}/${peca.wsid}?attributesToRetrieve=similars&${chave(algolia)}`);
    const vistos = new Set([peca.wsid]);
    const pecas = (ficha?.similars ?? [])
      .filter((s) => VENDIDO.test(s.id) && !vistos.has(s.id) && vistos.add(s.id))
      .map((s) => ({ wsid: s.id, codigo: s.c, descricao: null, marca: s.b ?? null }));
    if (!pecas.length) return [];
    const ofertas = await ofertasDe(pecas, opcoes);
    return pecas.map((p, i) => ({ peca: p, ofertas: ofertas[i] }));
  };

  globalThis.Leitores = { ...globalThis.Leitores, comolatti: { ler, similares, filiaisDoHtml } };
})();
