/**
 * Cotar um código nos B2Bs: o mesmo caminho para o painel lateral (botão
 * "Cotar") e para a estação de compras do CONECTA (servico.js).
 *
 * O leitor roda DENTRO da aba logada do site, com a chave que a própria
 * página usa (sessao-pagina.js). Nada de chave ou cookie passa por aqui.
 * Depende de escolha.js carregado antes.
 */
(() => {
  // abas: o endereço da aba, ou a lista deles (Haifer: a de Compras é .com.br, 11/11/2026)
  // tipo: como o leitor se autentica dentro da aba (ver lerNaPagina)
  // fornecedor: a chave do site no banco do CONECTA (fornecedores_b2b.chave)
  const SITES = [
    { fornecedor: 'roles', chave: 'comolatti', tipo: 'algolia', nome: 'Roles', abas: 'https://compreonline.roles.com.br/*', origem: 'https://compreonline.roles.com.br', leitor: 'leitores/comolatti.js' },
    { fornecedor: 'pellegrino', chave: 'comolatti', tipo: 'algolia', nome: 'Pellegrino', abas: 'https://compreonline.pellegrino.com.br/*', origem: 'https://compreonline.pellegrino.com.br', leitor: 'leitores/comolatti.js' },
    { fornecedor: 'dpk', chave: 'dpk', tipo: 'cabecalho', nome: 'DPK', abas: 'https://www.dpk.com.br/*', api: 'https://api.dpk.com.br', leitor: 'leitores/dpk.js' },
    { fornecedor: 'sky', chave: 'sky', tipo: 'formulario', nome: 'Sky Peças', abas: 'https://cliente.skypecas.com.br/*', leitor: 'leitores/sky.js' },
    // cliente: onde a página guarda o id do cliente que a API pede (lido na hora, nunca guardado)
    { fornecedor: 'barros', chave: 'barros', tipo: 'cabecalho', nome: 'Barros', abas: 'https://b2b.barros.com.br/*', api: 'https://dealer.barros.com.br', cliente: { chave: '@barrosAuth', campo: 'clientsId' }, leitor: 'leitores/barros.js' },
    { fornecedor: 'disape', chave: 'disape', tipo: 'cookie', nome: 'Disape', abas: 'https://loja.disape.com.br/*', leitor: 'leitores/disape.js' },
    { fornecedor: 'chg', chave: 'chg', tipo: 'cookie', nome: 'CHG Automotiva', abas: 'https://loja.chg.com.br/*', leitor: 'leitores/chg.js' },
    { fornecedor: 'universal', chave: 'universal', tipo: 'cookie', nome: 'Universal Automotive', abas: 'https://loja.universalautomotive.com.br/*', leitor: 'leitores/universal.js' },
    // RMP: o mesmo site (e o mesmo leitor) da Disape
    { fornecedor: 'rmp', chave: 'rmp', tipo: 'cookie', nome: 'Real', abas: 'https://loja.rmp.com.br/*', leitor: 'leitores/disape.js' },
    { fornecedor: 'rolemar', chave: 'rolemar', tipo: 'cookie', nome: 'Rolemar', abas: 'https://rolemarmaster.com/*', cabecalhos: { language: 'pt' }, leitor: 'leitores/rolemar.js' },
    { fornecedor: 'lucios', chave: 'lucios', tipo: 'aspnet', nome: 'Lucios', abas: 'http://www.vendamais.lucios.com.br/*', leitor: 'leitores/lucios.js' },
    { fornecedor: 'haifer', chave: 'haifer', tipo: 'tela', nome: 'Haifer', abas: ['https://*.haiferonline.com.br/*', 'https://*.haiferonline.com/*'], pagina: 'https://haiferonline.com.br/pedidosonline', leitor: 'leitores/haifer.js' },
    // pagina: a tela em que a cotação funciona; a aba é levada para lá se estiver em outra
    // emTeste (B2B novo em mapeamento): só na cotação do painel, fora da
    // estação do CONECTA até o fornecedor existir no banco — o gravar_cotacao
    // recusa a cotação inteira com um fornecedor que não conhece
    { fornecedor: 'vespor', chave: 'vespor', tipo: 'bearer', nome: 'Vespor Pro', abas: 'https://vesporpro.com.br/*', leitor: 'leitores/vespor.js' },
    { fornecedor: 'furacao', chave: 'furacao', tipo: 'xsrf', nome: 'Furacão', abas: 'https://vendas.furacao.com.br/*', pagina: 'https://vendas.furacao.com.br/vendas/sav/produtos', leitor: 'leitores/furacao.js' },
  ];

  // Roda no mundo da página (MAIN), por isso não usa nada de fora da função
  async function lerNaPagina(site, codigo, modo) {
    const sessao = window.__cotadorSessao;
    const vencida = () => Object.assign(new Error('sessão vencida'), { sessao: true });
    const conferir = async (r) => {
      if (r.status === 401 || r.status === 403) throw vencida();
      if (!r.ok) throw new Error(`erro ${r.status}`);
      // Sessão do site caída costuma redirecionar para a página de login (HTML)
      if (!/json/i.test(r.headers.get('content-type') || '')) throw vencida();
      return r.json();
    };
    let opcoes;
    if (site.tipo === 'cabecalho') {
      const cabecalhos = sessao?.cabecalhos(site.api) ?? {};
      if (!cabecalhos.authorization) return { erro: 'sem-sessao' };
      opcoes = { buscar: async (url) => conferir(await fetch(url, { headers: cabecalhos })) };
      if (site.cliente) {
        let cliente = null;
        try { cliente = JSON.parse(localStorage.getItem(site.cliente.chave) ?? 'null')?.[site.cliente.campo] ?? null; } catch { /* sem sessão */ }
        if (!cliente) return { erro: 'sem-sessao' };
        opcoes.cliente = String(cliente);
      }
    } else if (site.tipo === 'formulario') {
      // Sky: formulário no próprio site, com o cookie da aba. A resposta é
      // JSON servido como text/html; sessão caída devolve a página de login
      const buscar = async (caminho, { method = 'GET', body } = {}) => {
        const r = await fetch(caminho, {
          method, body, credentials: 'include',
          headers: { accept: 'application/json, text/javascript, */*; q=0.01', 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'x-requested-with': 'XMLHttpRequest' },
        });
        if (r.status === 401 || r.status === 403 || /\/login/i.test(r.url)) throw vencida();
        if (!r.ok) throw new Error(`erro ${r.status}`);
        try { return JSON.parse(await r.text()); } catch { throw vencida(); }
      };
      // O token da última busca feita na aba; sem ela, o que a página tiver no HTML
      const tag = document.querySelector('input[name="csrf_token"], meta[name="csrf_token"], meta[name="csrf-token"]');
      const csrf = sessao?.campo('csrf_token') || tag?.value || tag?.content || null;
      if (!csrf) return { erro: 'sem-sessao' };
      opcoes = { buscar, csrf };
    } else if (site.tipo === 'cookie') {
      // Sessão só no cookie da aba (Disape, CHG, Universal): texto (HTML) e JSON, GET ou
      // POST. Sessão caída redireciona para o login (Disape) ou a entrada (CHG)
      const pedir = async (caminho, opcoes = {}) => {
        const r = await fetch(caminho, { credentials: 'include', ...opcoes });
        if (r.status === 401 || r.status === 403 || /customer\/account\/login|\/entrada(\?|$)/i.test(r.url)) throw vencida();
        if (!r.ok) throw new Error(`erro ${r.status}`);
        return r.text();
      };
      opcoes = {
        // Com corpo, POST de formulário
        texto: (caminho, corpo) => pedir(caminho, corpo === undefined ? {} : { method: 'POST', body: corpo, headers: { 'content-type': 'application/x-www-form-urlencoded' } }),
        // Sem corpo, GET (CHG); com corpo, POST como o formulário do site (Disape)
        json: async (caminho, corpo) => {
          // Rolemar manda também "Language: pt", como o próprio site
          const cabecalhos = { accept: 'application/json, text/javascript, */*; q=0.01', 'x-requested-with': 'XMLHttpRequest', ...site.cabecalhos };
          const t = await pedir(caminho, corpo === undefined
            ? { headers: cabecalhos }
            : { method: 'POST', body: corpo, headers: { ...cabecalhos, 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8' } });
          try { return JSON.parse(t); } catch { throw vencida(); }
        },
        rastro: [],
      };
    } else if (site.tipo === 'aspnet') {
      // Lucios (ASP.NET WebForms): a busca é um "postback" da tela de pedido.
      // O estado novo de cada resposta segue só nas chamadas do leitor: a aba
      // não muda. Por isso o formulário da aba fica VELHO depois da primeira
      // cotação (o servidor já está noutro passo) e a mesma peça vinha às vezes
      // sim, às vezes não (24/10/2026). A cotação seguinte continua do estado
      // em que a anterior terminou, guardado na aba; se o vendedor mexeu na
      // tela desde então (__VIEWSTATE da aba mudou), volta ao formulário dela.
      // Uma tela nova por GET não serve: vem sem o cliente escolhido
      const form = document.querySelector('form#aspnetForm') ?? document.querySelector('form');
      const estadoDaAba = form?.querySelector('[name="__VIEWSTATE"]');
      // Toda página .aspx tem __VIEWSTATE: a de Pedidos é a que tem o editor do
      // item. Fora dela, o link de Pedidos do menu (com o "?a=" da sessão, lido
      // na hora e nunca guardado) leva a aba para lá
      if (!estadoDaAba || !form.querySelector('[name$="$txtOutrasRef"]')) {
        const link = [...document.querySelectorAll('a[href]')].find((a) => /\/?Pedidos\.aspx\?/i.test(a.getAttribute('href')));
        if (link) return { navegar: new URL(link.getAttribute('href'), location.href).href };
        return { erro: 'abra a tela de Pedidos na aba da Lucios e cote de novo' };
      }
      const endereco = form.action || new URL(form.getAttribute('action') || '', location.href).href;
      // Os campos como o ASP.NET AJAX manda: inclusive os desabilitados; botão não.
      // O valor pela propriedade (o que está digitado na tela), senão o atributo
      const campo = (c) => {
        if (c.tagName === 'SELECT') return c.value ?? (c.querySelector('option[selected]') ?? c.querySelector('option'))?.getAttribute('value') ?? '';
        if (c.tagName === 'TEXTAREA') return c.value ?? c.textContent;
        return c.value ?? c.getAttribute('value') ?? '';
      };
      const camposDe = (f) => {
        const campos = new URLSearchParams();
        for (const c of f.querySelectorAll('input[name], select[name], textarea[name]')) {
          const tipo = (c.getAttribute('type') || '').toLowerCase();
          if (/^(submit|button|image|reset|file)$/.test(tipo)) continue;
          if (/^(checkbox|radio)$/.test(tipo) && !(c.checked ?? c.hasAttribute('checked'))) continue;
          campos.set(c.getAttribute('name'), campo(c));
        }
        return campos;
      };
      const memoria = (window.__cotadorAspnet ??= {});
      const vistoNaAba = campo(estadoDaAba);
      const base = memoria.base && memoria.vistoNaAba === vistoNaAba ? new URLSearchParams(memoria.base) : camposDe(form);
      const guardar = () => Object.assign(memoria, { base: base.toString(), vistoNaAba });
      const estado = ['__VIEWSTATE', '__VIEWSTATEGENERATOR', '__EVENTVALIDATION'];
      // O que o leitor fez, passo a passo, para o painel mostrar quando não
      // acha a peça. Só nomes de controle, códigos e tamanhos: nada da conta
      const rastro = [memoria.base && memoria.vistoNaAba === vistoNaAba ? 'partiu do fim da cotação anterior' : 'partiu do formulário da aba'];
      const passo = (campos, parcial) => {
        const disparo = Object.entries(campos).find(([n]) => /ScriptManager/i.test(n))?.[1]?.split('|')[1] || campos.__EVENTTARGET;
        return parcial ? String(disparo || '?').replace(/^ctl00\$cphMaster\$/, '') : 'pesquisa (página inteira)';
      };
      // Os campos que a resposta trouxe (HTML vindo do servidor: pelo atributo)
      // passam a valer no próximo postback; inclui __VIEWSTATE da página inteira
      const aplicarCampos = (raiz) => {
        for (const c of raiz.querySelectorAll('input[name], select[name], textarea[name]')) {
          const tipo = (c.getAttribute('type') || '').toLowerCase();
          if (/^(submit|button|image|reset|file)$/.test(tipo)) continue;
          const nome = c.getAttribute('name');
          if (/^(checkbox|radio)$/.test(tipo)) {
            if (c.hasAttribute('checked')) base.set(nome, c.getAttribute('value') ?? 'on');
            else if (base.get(nome) === (c.getAttribute('value') ?? 'on')) base.delete(nome);
            continue;
          }
          base.set(nome, c.tagName === 'SELECT'
            ? (c.querySelector('option[selected]') ?? c.querySelector('option'))?.getAttribute('value') ?? ''
            : c.tagName === 'TEXTAREA' ? c.textContent : c.getAttribute('value') ?? '');
        }
      };
      // parcial: o UpdatePanel (resposta "delta"); senão a página inteira
      const postback = async (campos, { parcial = true } = {}) => {
        const corpo = new URLSearchParams(base);
        for (const [nome, valor] of Object.entries(campos)) corpo.set(nome, valor);
        if (parcial) corpo.set('__ASYNCPOST', 'true');
        const r = await fetch(endereco, {
          method: 'POST', body: corpo, credentials: 'include',
          headers: parcial
            ? { 'content-type': 'application/x-www-form-urlencoded; charset=utf-8', 'x-microsoftajax': 'Delta=true', 'x-requested-with': 'XMLHttpRequest', 'cache-control': 'no-cache' }
            : { 'content-type': 'application/x-www-form-urlencoded' },
        });
        if (r.status === 401 || r.status === 403 || /login/i.test(r.url)) throw vencida();
        if (!r.ok) throw new Error(`erro ${r.status}`);
        const texto = await r.text();
        rastro.push(`${passo(campos, parcial)} → ${r.status}, ${texto.length} caracteres${parcial && !/^\d+\|/.test(texto) ? ' (fora do formato)' : ''}`);
        if (!parcial) {
          const doc = new DOMParser().parseFromString(texto, 'text/html');
          if (!doc.querySelector('[name="__VIEWSTATE"]')) throw vencida();
          aplicarCampos(doc.querySelector('form#aspnetForm') ?? doc);
          guardar();
          return texto;
        }
        const delta = globalThis.LeitoresComum.lerDelta(texto);
        if (!delta || delta.redirecionar) throw vencida();
        if (delta.erro) throw new Error(`a Lucios respondeu erro: ${String(delta.erro).slice(0, 80)}`);
        // Como o navegador: os painéis novos trocam os campos da tela, e o
        // próximo postback manda os valores DELES (o código que ficou em
        // "Outras Referências", a peça aberta), não os da tela antiga
        for (const html of Object.values(delta.paineis))
          aplicarCampos(new DOMParser().parseFromString(`<!doctype html><html><body><form>${html}</form></body></html>`, 'text/html'));
        for (const nome of estado) if (delta.campos[nome] != null) base.set(nome, delta.campos[nome]);
        guardar();
        return delta;
      };
      opcoes = { postback, rastro };
    } else if (site.tipo === 'tela') {
      // Haifer (Blazor Server): sem chamada que dê para repetir; o leitor usa a
      // própria tela da aba (escreve na Busca, Enter, lê a grade)
      if (!document.querySelector('.pesquisa .busca input, .busca input.dxbl-text-edit-input')) {
        // Sem a Busca: na tela de login é sessão caída; noutra tela, avisa
        if (document.querySelector('input[type="password"]')) return { erro: 'sem-sessao' };
        return { erro: 'abra a tela "Pedido On-line" na aba da Haifer e cote de novo' };
      }
      opcoes = { documento: document, esperar: (ms) => new Promise((ok) => setTimeout(ok, ms)), rastro: [] };
    } else if (site.tipo === 'bearer') {
      // Vespor (Angular): a chave de acesso e os dados do login que o próprio
      // site guarda no navegador. Os códigos de cliente e de filial vão só na
      // chamada, lidos na hora: nunca guardados nem devolvidos
      const token = localStorage.getItem('authToken') || localStorage.getItem('accessToken');
      let login = null;
      try { login = JSON.parse(localStorage.getItem('dadosLogin') ?? 'null'); } catch { /* sem login */ }
      const u = login?.usuario;
      if (!token || !u?.codcliente) return { erro: 'sem-sessao' };
      const buscar = async (caminho, corpo) => {
        const r = await fetch(caminho, {
          method: 'POST', credentials: 'include', body: JSON.stringify(corpo),
          headers: { accept: 'application/json', 'content-type': 'application/json', authorization: `Bearer ${token}` },
        });
        if (r.status === 401 || r.status === 403) throw vencida();
        if (!r.ok) throw new Error(`erro ${r.status}`);
        try { return JSON.parse(await r.text()); } catch { throw vencida(); }
      };
      const contexto = { codfilial: u.codfilial, codfilori: u.codfilori, codcliente: u.codcliente, codclienteloja: u.codclienteloja };
      opcoes = { buscar, contexto, rastro: [] };
    } else if (site.tipo === 'xsrf') {
      // Furacão (Laravel): o token XSRF-TOKEN que o próprio site lê da página
      // e manda no cabeçalho; o cliente e a unidade, da última busca da aba
      const xsrf = decodeURIComponent(document.cookie.match(/(?:^|;\s*)XSRF-TOKEN=([^;]*)/)?.[1] ?? '') || sessao?.campo('x-xsrf-token');
      if (!xsrf) return { erro: 'sem-sessao' };
      const buscar = async (caminho, { method = 'GET', body } = {}) => {
        const r = await fetch(caminho, {
          method, body, credentials: 'include',
          headers: { accept: 'application/json, text/plain, */*', 'content-type': 'application/json;charset=utf-8', 'x-requested-with': 'XMLHttpRequest', 'x-xsrf-token': xsrf },
        });
        if (r.status === 419) throw vencida(); // Laravel: token vencido
        if (r.status === 401 || r.status === 403 || /\/login/i.test(r.url)) throw vencida();
        if (!r.ok) throw new Error(`erro ${r.status}`);
        // O "Similar" responde JSON com content-type text/html
        try { return JSON.parse(await r.text()); } catch { throw vencida(); }
      };
      // Sem o cliente a Furacão responde vazio. Ele vem da busca que a tela
      // Produtos faz ao abrir: aba recém-aberta ainda pode estar carregando
      let cliente = sessao?.campo('cliente_selecionado');
      for (let i = 0; !cliente && i < 32; i++) {
        await new Promise((ok) => setTimeout(ok, 250));
        cliente = sessao?.campo('cliente_selecionado');
      }
      if (!cliente) return { erro: 'sem-sessao' };
      opcoes = { buscar, cliente, unidade: sessao?.campo('unidade') ?? null };
    } else {
      const alg = sessao?.porHost(/algolia.net$/i);
      const apiKey = alg?.cabecalhos['x-algolia-api-key'];
      if (!apiKey) return { erro: 'sem-sessao' };
      const algolia = { origem: alg.origem, apiKey, appId: alg.cabecalhos['x-algolia-application-id'] };
      const buscar = async (url, { method = 'GET', body } = {}) => {
        const externo = new URL(url).origin !== location.origin;
        const headers = externo
          ? { 'content-type': 'application/x-www-form-urlencoded' } // como o Algolia do site: sem preflight
          : { accept: 'application/json', 'x-requested-with': 'XMLHttpRequest' };
        return conferir(await fetch(url, { method, body, headers, credentials: externo ? 'omit' : 'include' }));
      };
      opcoes = { buscar, algolia, origem: site.origem, fornecedor: site.nome };
    }
    try {
      const leitor = globalThis.Leitores[site.chave];
      const r = await leitor.ler(codigo, opcoes);
      // Leitor sem similares mapeados só não busca
      if (r.peca && leitor.similares && globalThis.Escolha.buscarSimilares(modo, globalThis.Escolha.escolher(r.ofertas))) {
        try {
          r.similares = await leitor.similares(r.peca, opcoes);
        } catch (e) {
          r.erroSimilares = e.message;
        }
      }
      if (opcoes.rastro) r.rastro = opcoes.rastro;
      return r;
    } catch (e) {
      return { erro: e.sessao ? 'sem-sessao' : e.message, ...(opcoes.rastro && { rastro: opcoes.rastro }) };
    }
  }

  // Última leitura de cada site deu "sem sessão"? Vale até uma dar certo.
  const semSessao = new Set();

  /** Faz `acao` na aba e espera a página carregar (no máximo `limite` ms) */
  const esperarCarregar = (tabId, acao, limite = 20000) =>
    new Promise((ok) => {
      const fim = () => {
        chrome.tabs.onUpdated.removeListener(ouvir);
        clearTimeout(relogio);
        ok();
      };
      const ouvir = (id, info) => id === tabId && info.status === 'complete' && fim();
      const relogio = setTimeout(fim, limite);
      chrome.tabs.onUpdated.addListener(ouvir);
      acao();
    });

  /** Leva a aba para o endereço e espera a página carregar */
  const irPara = (tabId, url) => esperarCarregar(tabId, () => chrome.tabs.update(tabId, { url }));

  // Depois de recarregar, o site refaz as próprias chamadas: é delas que
  // sessao-pagina.js aprende o token (DPK, Barros, Furacão)
  const ASSENTAR_MS = 1500;
  const esperar = (ms) => new Promise((ok) => setTimeout(ok, ms));
  let assentar = ASSENTAR_MS;

  /** F5 na aba, como o vendedor faria, e espera o site assentar */
  const recarregar = async (tabId) => {
    await esperarCarregar(tabId, () => chrome.tabs.reload(tabId));
    await esperar(assentar);
  };

  /**
   * As abas dos B2Bs não podem dormir: com a "Economia de memória" o Chrome
   * descarta aba parada, e a cotação dava "Cannot access contents of the
   * page" ou "recarregue a aba" (24/10/2026). Marca a aba para o Chrome não
   * descartar; a que já dormiu acorda aqui.
   */
  const protegerAba = async (aba) => {
    if (aba.autoDiscardable !== false) await chrome.tabs.update(aba.id, { autoDiscardable: false }).catch(() => {});
    if (aba.discarded) await recarregar(aba.id);
  };

  // O ASP.NET (Lucios) não recarrega sozinho: a aba mostra o resultado de um
  // envio de formulário, e o F5 repete o envio (o Chrome pergunta e trava)
  const podeRecarregar = (site) => site.tipo !== 'aspnet';

  // A tela do ASP.NET (Lucios) tem um estado só por sessão, e a da Haifer é
  // uma Busca só: duas cotações ao mesmo tempo na mesma aba (painel +
  // estação) se atropelam. Uma de cada vez
  const filas = new Map();
  const cotarSite = (site, codigo, modo) => {
    if (site.tipo !== 'aspnet' && site.tipo !== 'tela') return cotarSiteJa(site, codigo, modo);
    const vez = (filas.get(site.fornecedor) ?? Promise.resolve()).then(() => cotarSiteJa(site, codigo, modo));
    filas.set(site.fornecedor, vez.catch(() => {}));
    return vez;
  };

  const cotarSiteJa = async (site, codigo, modo) => {
    const [aba] = await chrome.tabs.query({ url: site.abas });
    if (!aba) return { site, erro: `Abra o ${site.nome} logado numa aba.` };
    // O relogin (relogin.js) está entrando no site agora: o F5 da cotação o atropelaria
    if (globalThis.Relogin?.relogando.has(site.fornecedor)) return { site, sessao: true, erro: `${site.nome}: entrando de novo no site, cote de novo em 1 minuto.` };
    await protegerAba(aba);
    // Furacão: na tela Inicial a busca não traz nada; só na Produtos. O
    // caminho vale no endereço da própria aba (com ou sem "www": Haifer)
    if (site.pagina) {
      const caminho = new URL(site.pagina).pathname;
      let naPagina = false;
      try { naPagina = new URL(aba.url).pathname.startsWith(caminho); } catch { /* aba sem endereço */ }
      if (!naPagina) await irPara(aba.id, aba.url ? new URL(caminho, aba.url).href : site.pagina);
    }
    const alvo = { tabId: aba.id };
    const ler = async () => {
      await chrome.scripting.executeScript({ target: alvo, files: ['correspondencia.js', 'escolha.js', 'leitores/comum.js', site.leitor], world: 'MAIN' });
      const [{ result }] = await chrome.scripting.executeScript({
        target: alvo, world: 'MAIN', func: lerNaPagina, args: [site, codigo, modo],
      });
      return result;
    };
    // A aba travada (página de erro do Chrome, aba que sumiu) vira resposta, não exceção
    const lerSemCair = () => ler().catch((e) => ({ travou: e.message }));
    let result = await lerSemCair();
    // Aba travada ou sessão caída: F5 e mais uma tentativa, sozinho, como o
    // vendedor faria (antes o painel pedia o F5 a quem estivesse no PC)
    let recarregou = false;
    if (podeRecarregar(site) && (result?.travou || result?.erro === 'sem-sessao')) {
      await recarregar(aba.id);
      recarregou = true;
      result = await lerSemCair();
    }
    if (result?.travou) throw new Error(result.travou);
    // Lucios: a aba estava fora da tela de Pedidos; o leitor achou o link no
    // menu da página. Leva a aba para lá e lê de novo, uma vez só
    if (result?.navegar) {
      await irPara(aba.id, result.navegar);
      result = await ler();
      if (result?.navegar) result = { erro: 'a aba não abriu a tela de Pedidos' };
    }
    if (result?.erro === 'sem-sessao') {
      semSessao.add(site.fornecedor);
      const erro = recarregou
        ? `${site.nome}: a sessão caiu (mesmo recarregando a aba). Entre de novo no site e cote de novo.`
        : `${site.nome}: recarregue a aba do site (F5) ou pesquise qualquer peça nela, e cote de novo.`;
      return { site, sessao: true, erro };
    }
    if (result?.erro) return { site, erro: `${site.nome}: ${result.erro}`, rastro: result.rastro };
    semSessao.delete(site.fornecedor);
    return { site, modo, ...result, escolha: Escolha.escolher(result.ofertas) };
  };

  /** Os sites em paralelo; um site que falha não derruba os outros. O que está
   * em teste (emTeste) só entra quando quem pede é o painel */
  const cotarTodos = (codigo, modo, { comEmTeste = false } = {}) =>
    Promise.all(SITES.filter((s) => comEmTeste || !s.emTeste).map((s) => cotarSite(s, codigo, modo).catch((e) => ({ site: s, erro: `${s.nome}: ${e.message}` }))));

  /** Cada site: `fora` (sem aba aberta), `deslogado` (última leitura sem sessão) ou `ok`. */
  const situacaoDosSites = async () => {
    const sites = {};
    // O vigia das sessões (relogin.js) viu a aba na tela de login: deslogado
    // já, sem esperar uma cotação falhar
    const { sessoes = {} } = (await chrome.storage?.local.get('sessoes')) ?? {};
    for (const s of SITES.filter((x) => !x.emTeste)) {
      const abas = await chrome.tabs.query({ url: s.abas });
      // A estação pergunta a cada minuto (e o relógio da extensão, a cada
      // 5): aproveita para não deixar a aba dormir. Sem esperar: o "ola" tem 2 s
      abas.forEach((aba) => void protegerAba(aba).catch(() => {}));
      sites[s.fornecedor] = !abas.length ? 'fora' : semSessao.has(s.fornecedor) || sessoes[s.fornecedor]?.situacao === 'login' ? 'deslogado' : 'ok';
    }
    return sites;
  };

  // Só os campos que o banco conhece: nada além do que o leitor leu do site
  const oferta = (o) => ({
    local: o.local, emSP: !!o.emSP, preco: o.preco ?? null, quantidade: o.quantidade ?? null,
    disponivel: !!o.disponivel, proximidade: o.proximidade ?? null,
  });

  /**
   * O resultado de um site no formato de `gravar_cotacao` (CONECTA,
   * supabase/cotador-banco.sql). Similares só entram quando foram buscados:
   * sem a chave, o banco mantém os que já tinha.
   */
  const paraBanco = (r) => {
    if (r.erro) return { fornecedor: r.site.fornecedor, peca: null, ofertas: [], erro: r.erro };
    const item = {
      fornecedor: r.site.fornecedor,
      peca: r.peca ? { codigo: r.peca.codigo, marca: r.peca.marca ?? null, descricao: r.peca.descricao ?? null, grupo: null } : null,
      ofertas: (r.ofertas ?? []).map(oferta),
      erro: null,
    };
    if (r.similares)
      item.similares = r.similares.map((s) => ({
        codigo: s.peca.codigo, marca: s.peca.marca ?? null, descricao: s.peca.descricao ?? null, ofertas: (s.ofertas ?? []).map(oferta),
      }));
    return item;
  };

  globalThis.Cotacao = {
    SITES, cotarSite, cotarTodos, situacaoDosSites, paraBanco,
    // Os testes não esperam o site assentar
    _assentar: (ms) => (assentar = ms),
  };
})();
