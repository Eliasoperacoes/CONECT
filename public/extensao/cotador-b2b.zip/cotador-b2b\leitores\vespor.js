/**
 * Leitor da Vespor Pro (ver docs/fornecedores/vespor.md). Na estação desde
 * 11/11/2026 (CONECTA: supabase/cotador-vespor.sql).
 *
 * API própria do site (Angular), na mesma origem, com a chave de acesso que o
 * site guarda no navegador: quem chama passa `buscar(caminho, corpo)` (POST
 * JSON) e o `contexto` (os códigos de cliente e de filial do login, lidos da
 * aba a cada cotação: vão só na chamada, nunca no resultado nem no rastro).
 *
 * Mapeado do código público do site (11/11/2026): a busca devolve a peça e
 * as equivalentes que a Vespor vende, cada uma com codproduto, descproduto,
 * descfornecedor (a marca), estoque e vlr_x3 (o preço); /info traz a ficha
 * e as filiais. O formato das filiais ainda não foi visto: o rastro mostra
 * os nomes dos campos para fechar o mapeamento.
 * Depende de Correspondencia.
 */
(() => {
  const API = '/b2b/api/v1/produto';
  const FORNECEDOR = 'Vespor Pro';
  // O preço e o estoque da busca são os da filial que atende a conta,
  // Ribeirão Preto (SP), enquanto as outras filiais não estiverem mapeadas.
  // Entrega só em Pirassununga (Elias, 11/11/2026)
  const LOCAL_DA_CONTA = { local: 'RIBEIRAO PRETO', emSP: true, proximidade: 1 };

  const norm = (s) => Correspondencia.normalizar(s ?? '');
  const numero = (v) => (typeof v === 'number' ? v : Number(String(v ?? '').replace(/\./g, '').replace(',', '.')) || 0);

  // O que pode aparecer no rastro: os nomes dos campos e, de valor, só os do
  // produto e da filial. Nada do cliente, do usuário, da loja ou do documento
  const CAMPO_SEGURO = /^(codproduto|descproduto|descfornecedor|estoque|vlr_x3|vlr_lc|mensagemestoque|descfilial|filial|cidade|uf|codfilial)$/i;
  const chaves = (o) => (o && typeof o === 'object' ? Object.keys(o).join(', ') || '(vazio)' : String(typeof o));
  const amostra = (o) => JSON.stringify(Object.fromEntries(Object.entries(o ?? {}).filter(([k, v]) => CAMPO_SEGURO.test(k) && (v === null || typeof v !== 'object'))));

  const pecaDo = (p) => ({ codigo: String(p.codproduto ?? '').trim(), descricao: p.descproduto?.trim() || null, marca: p.descfornecedor?.trim() || null });

  const ofertaDo = (p) => {
    const preco = numero(p.vlr_x3);
    const quantidade = numero(p.estoque);
    return { fornecedor: FORNECEDOR, codigo: String(p.codproduto ?? '').trim(), ...LOCAL_DA_CONTA, preco, quantidade, disponivel: quantidade > 0 && preco > 0 };
  };

  // As outras peças da busca são as equivalentes da Vespor: só as que ela tem
  const equivalentesDe = (produtos, menos) =>
    produtos
      .filter((p) => p !== menos && numero(p.vlr_x3) > 0 && numero(p.estoque) > 0)
      .map((p) => ({ peca: pecaDo(p), ofertas: [ofertaDo(p)] }));

  const ler = async (codigo, { buscar, contexto, rastro = [] }) => {
    const r = await buscar(`${API}/pesquisa`, { ...contexto, pesquisa: codigo, itenspagina: 20, pagina: 1, codcondpag: null, marcas: [], categorias: [] });
    rastro.push(`pesquisa: ${chaves(r)}`);
    if (r?.message === 'Nenhum produto encontrado') return { peca: null, ofertas: [] };
    if (!Array.isArray(r?.produtos)) throw new Error(`a busca não devolveu a lista de peças (veio: ${chaves(r)})`);
    if (!r.produtos.length) return { peca: null, ofertas: [] };
    rastro.push(`produto: ${chaves(r.produtos[0])}`);

    const item = r.produtos.find((p) => norm(p.codproduto) === norm(codigo));
    if (!item) {
      const equivalentes = equivalentesDe(r.produtos, null);
      return equivalentes.length ? { peca: null, ofertas: [], similares: equivalentes } : { peca: null, ofertas: [] };
    }
    rastro.push(`peça: ${amostra(item)}`);

    // A ficha com as filiais: só para mapear (o formato vem no rastro)
    try {
      const info = await buscar(`${API}/info`, { ...contexto, codproduto: item.codproduto, codcondpag: null });
      rastro.push(`info: ${chaves(info)}`);
      for (const [nome, valor] of Object.entries(info ?? {})) {
        if (Array.isArray(valor) && valor.length && typeof valor[0] === 'object') rastro.push(`info.${nome}[0]: ${chaves(valor[0])} → ${amostra(valor[0])}`);
      }
    } catch (e) {
      rastro.push(`info: ${e.message}`);
    }

    const peca = pecaDo(item);
    // As equivalentes já vieram na busca: os similares não pedem nada a mais
    Object.defineProperty(peca, 'equivalentes', { value: equivalentesDe(r.produtos, item), enumerable: false });
    return { peca, ofertas: [ofertaDo(item)] };
  };

  const similares = async (peca) => peca.equivalentes ?? [];

  globalThis.Leitores = { ...globalThis.Leitores, vespor: { ler, similares } };
})();
