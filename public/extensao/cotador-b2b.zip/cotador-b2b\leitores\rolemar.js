/**
 * Leitor da Rolemar (ver docs/fornecedores/rolemar.md).
 *
 * Chamadas JSON na própria origem, com o cookie da aba, todas POST de
 * formulário com a filial da conta (`cod_emp`, que a página guarda em
 * window._config):
 *   /ajax-busca                 → data[]: id, codigo_fabricante, fabricante, preco, estoque
 *   /ajax-produto-detalhe       → dados.produto_filial[]: preço e estoque em CADA filial
 *   /ajax-produtos-similares    → itens[]: os similares da Rolemar
 *
 * A busca é por referência cruzada: "OC90" (Mahle) traz a WEGA WO130. Se
 * nenhuma linha tem o código pedido, as que vieram são equivalentes e vão
 * como similares (como a Haifer).
 *
 * Preço e estoque da peça vêm do detalhe, uma oferta por filial: 4 em SP e 3
 * fora (Joinville pode sair mais barata; a regra da casa põe SP na frente e
 * fora de SP com a etiqueta).
 *
 * Quem chama passa json(caminho, corpo) (cotacao.js, tipo cookie).
 * Depende de Correspondencia.
 */
(() => {
  const FORNECEDOR = 'Rolemar';
  const PAGINAS = 3;
  const SIMILARES = 6; // detalhes abertos para os similares (cada um é uma chamada)
  const norm = (s) => Correspondencia.normalizar(s ?? '');
  const numero = (v) => Number(String(v ?? '').replace(',', '.')) || 0;

  // Filiais conhecidas (ajax-lista-filiais, 24/10/2026); proximidade:
  // 1 = mais perto de Pirassununga (desempate de preço). Filial nova cai no
  // "-SP" do nome da cidade
  const FILIAIS = {
    CAS: { nome: 'CAMPINAS', proximidade: 1 },
    SPO: { nome: 'SÃO PAULO', proximidade: 2 },
    SJC: { nome: 'S. J. DOS CAMPOS', proximidade: 3 },
    MAR: { nome: 'MARÍLIA', proximidade: 3 },
    GOI: { nome: 'GOIÂNIA-GO', proximidade: 4 },
    JOI: { nome: 'JOINVILLE-SC', proximidade: 5 },
    VIT: { nome: 'CARIACICA-ES', proximidade: 6 },
  };

  const formulario = (campos) => new URLSearchParams(campos).toString();

  /** A filial da conta: a página guarda; senão, a lista de filiais diz */
  const filialDaConta = async (json) => {
    const daPagina = globalThis._config?.cod_emp;
    if (daPagina) return String(daPagina);
    const lista = await json('/ajax-lista-filiais', '');
    if (!lista?.cod_emp) throw new Error('a Rolemar não disse a filial da conta (abra o site logado e cote de novo)');
    return String(lista.cod_emp);
  };

  const buscar = async (json, codigo, codEmp, page) => {
    const r = await json('/ajax-busca', formulario({ busca: codigo, page: String(page), cod_emp: codEmp }));
    if (!Array.isArray(r?.data)) throw new Error(`a busca não devolveu a lista de peças (veio: ${JSON.stringify(r)?.slice(0, 80) ?? 'nada'})`);
    return r;
  };

  const pecaDe = (i) => ({ id: String(i.id), codigo: i.codigo_fabricante, marca: i.fabricante ?? null, descricao: i.item ?? null });

  /** Uma oferta por filial, do detalhe */
  const ofertasDoDetalhe = (codigo, filiais) =>
    filiais.map((f) => {
      const conhecida = FILIAIS[f.PREFIXO];
      const preco = numero(f.PRECO);
      const quantidade = numero(f.QTDEESTOQUE);
      return {
        fornecedor: FORNECEDOR, codigo, local: conhecida?.nome ?? String(f.CIDADE ?? f.FILIAL ?? 'ROLEMAR').toUpperCase(),
        emSP: conhecida ? conhecida.proximidade <= 3 : /-SP$/i.test(String(f.CIDADE ?? '')),
        proximidade: conhecida?.proximidade ?? null, preco, quantidade, disponivel: quantidade > 0 && preco > 0,
      };
    });

  /** Só a filial da conta, do próprio item (busca ou similares): quando o detalhe não vem */
  const ofertaDoItem = (i) => {
    const preco = numero(i.valor_final ?? i.preco);
    const quantidade = numero(i.estoque);
    return [{ fornecedor: FORNECEDOR, codigo: i.codigo_fabricante, local: 'ROLEMAR', emSP: true, proximidade: null, preco, quantidade, disponivel: quantidade > 0 && preco > 0 }];
  };

  const comDetalhe = async (json, i, codEmp) => {
    const r = await json('/ajax-produto-detalhe', formulario({ codproduto: String(i.id), cod_emp: codEmp }));
    const filiais = r?.dados?.produto_filial;
    if (!Array.isArray(filiais) || !filiais.length) throw new Error(`o detalhe da peça ${i.codigo_fabricante} não trouxe as filiais`);
    return { peca: pecaDe(i), ofertas: ofertasDoDetalhe(i.codigo_fabricante, filiais) };
  };

  // O que a busca trouxe além da peça, para os similares
  let ultima = { id: null, outras: [] };

  const ler = async (codigo, { json, rastro = [] }) => {
    const alvo = norm(codigo);
    const codEmp = await filialDaConta(json);
    const linhas = [];
    let achada = null;
    for (let page = 1; page <= PAGINAS && !achada; page++) {
      const r = await buscar(json, codigo, codEmp, page);
      linhas.push(...r.data);
      achada = r.data.find((i) => norm(i.codigo_fabricante) === alvo) ?? null;
      if (!r.data.length || page >= Number(r.ultima_pagina ?? 1)) break;
    }
    rastro.push(`busca ${codigo} (filial ${codEmp}): ${linhas.length} linhas, ${achada ? `achou ${achada.codigo_fabricante} ${achada.fabricante ?? ''} (id ${achada.id})` : 'nenhuma com o código'}`);
    const outras = linhas.filter((i) => i !== achada);
    ultima = { id: achada ? String(achada.id) : null, outras };
    if (!achada) {
      // Referência cruzada: o que veio são equivalentes de outras marcas
      const similares = await abrir(json, outras, codEmp, rastro);
      return similares.length ? { peca: null, ofertas: [], similares } : { peca: null, ofertas: [] };
    }
    const r = await comDetalhe(json, achada, codEmp);
    rastro.push(`detalhe ${achada.codigo_fabricante}: ${r.ofertas.length} filiais`);
    return r;
  };

  /** Abre o detalhe de cada um (no máximo SIMILARES); o que falhar fica com a filial da conta */
  const abrir = async (json, itens, codEmp, rastro = []) => {
    const vistos = new Set();
    const unicos = itens.filter((i) => !vistos.has(String(i.id)) && vistos.add(String(i.id)));
    const saida = [];
    for (const [n, i] of unicos.entries()) {
      if (n >= SIMILARES) { saida.push({ peca: pecaDe(i), ofertas: ofertaDoItem(i) }); continue; }
      try {
        saida.push(await comDetalhe(json, i, codEmp));
      } catch (e) {
        rastro.push(`similar ${i.codigo_fabricante}: ${e.message}; ficou só a filial da conta`);
        saida.push({ peca: pecaDe(i), ofertas: ofertaDoItem(i) });
      }
    }
    return saida;
  };

  /** Os similares da Rolemar e os equivalentes que vieram na mesma busca */
  const similares = async (peca, { json, rastro = [] }) => {
    const codEmp = await filialDaConta(json);
    const r = await json('/ajax-produtos-similares', formulario({ cod_emp: codEmp, codproduto: String(peca.id) }));
    const itens = Array.isArray(r?.itens) ? r.itens : [];
    const daBusca = String(peca.id) === ultima.id ? ultima.outras : [];
    return abrir(json, [...itens, ...daBusca].filter((i) => String(i.id) !== String(peca.id)), codEmp, rastro);
  };

  globalThis.Leitores = { ...globalThis.Leitores, rolemar: { ler, similares, FILIAIS, PAGINAS, SIMILARES } };
})();
