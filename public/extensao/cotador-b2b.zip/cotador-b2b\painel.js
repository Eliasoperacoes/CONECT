/**
 * Painel lateral: controla a gravação e mostra o que foi capturado.
 */

const $ = (id) => document.getElementById(id);
const IDS_SCRIPTS = ['cotador-captura', 'cotador-ponte'];

const abaAtual = async () => {
  const [aba] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return aba;
};

const mostrarEstado = (texto, erro = false) => {
  $('estado').textContent = texto;
  $('estado').className = erro ? 'estado erro' : 'estado';
};

/**
 * Registra os scripts para a origem do site (assim valem também depois de
 * navegar ou recarregar) e injeta já na aba aberta (para não precisar
 * recarregar a página logada).
 */
const iniciar = async () => {
  const codigo = $('codigo').value.trim();
  if (Correspondencia.normalizar(codigo).length < 3) return mostrarEstado('Digite um código com 3 ou mais caracteres.', true);

  const aba = await abaAtual();
  if (!aba?.url?.startsWith('http')) return mostrarEstado('Abra o site B2B nesta janela antes de iniciar.', true);
  const origem = new URL(aba.url).origin;

  await chrome.scripting.unregisterContentScripts({ ids: IDS_SCRIPTS }).catch(() => {});
  await chrome.scripting.registerContentScripts([
    { id: 'cotador-captura', matches: [`${origem}/*`], js: ['sem-conta.js', 'captura-pagina.js'], runAt: 'document_start', world: 'MAIN', allFrames: true },
    { id: 'cotador-ponte', matches: [`${origem}/*`], js: ['correspondencia.js', 'ponte.js'], runAt: 'document_start', allFrames: true },
  ]);

  const tudo = $('gravar-tudo').checked;
  await chrome.storage.local.set({ gravacao: { codigo, origem, tudo, inicio: Date.now() } });

  // Recarrega a aba em vez de injetar na página aberta: uma página que já tinha
  // a captura antiga (antes de um ↻ da extensão) ficaria com a proteção antiga
  await chrome.tabs.reload(aba.id);

  atualizarBotoes(true);
  mostrarEstado(`Gravando ${tudo ? 'TUDO' : `"${codigo}"`} em ${origem}. A aba foi recarregada: pesquise a peça no site.`);
};

const parar = async () => {
  await chrome.scripting.unregisterContentScripts({ ids: IDS_SCRIPTS }).catch(() => {});
  await chrome.storage.local.set({ gravacao: null });
  atualizarBotoes(false);
  mostrarEstado('Gravação parada. Recarregue a aba do site para retirar a captura dela.');
};

const atualizarBotoes = (gravando) => {
  $('iniciar').hidden = gravando;
  $('parar').hidden = !gravando;
  $('codigo').disabled = gravando;
};

/**
 * Para sites que entregam o resultado já montado no HTML (sem fetch/XHR):
 * procura o código no texto da página e devolve o bloco que o contém.
 */
function capturarDaPagina(codigo) {
  const achados = [];
  const andarilho = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  const caminho = (el) => {
    const partes = [];
    for (let e = el; e && e !== document.body && partes.length < 6; e = e.parentElement) {
      partes.unshift(e.tagName.toLowerCase() + (e.id ? `#${e.id}` : '') + (e.classList.length ? '.' + [...e.classList].slice(0, 2).join('.') : ''));
    }
    return partes.join(' > ');
  };
  for (let no = andarilho.nextNode(); no && achados.length < 5; no = andarilho.nextNode()) {
    if (!Correspondencia.encontrar(no.textContent, codigo)) continue;
    // Sobe até um bloco que pareça uma linha de produto (tem mais texto que só o código)
    let bloco = no.parentElement;
    while (bloco.parentElement && bloco.parentElement !== document.body && bloco.innerText.length < 120) bloco = bloco.parentElement;
    achados.push({ seletor: caminho(bloco), texto: bloco.innerText.slice(0, 1500), html: bloco.outerHTML.slice(0, 20000) });
  }
  return { pagina: location.href, achados };
}

const capturarPagina = async () => {
  const codigo = $('codigo').value.trim();
  if (Correspondencia.normalizar(codigo).length < 3) return mostrarEstado('Digite o código antes de capturar.', true);
  const aba = await abaAtual();
  const alvo = { tabId: aba.id, allFrames: true };
  await chrome.scripting.executeScript({ target: alvo, files: ['correspondencia.js'] });
  const resultados = await chrome.scripting.executeScript({ target: alvo, func: capturarDaPagina, args: [codigo] });

  const { capturas } = await chrome.storage.local.get({ capturas: [] });
  let novos = 0;
  for (const { result } of resultados) {
    for (const a of result?.achados ?? []) {
      capturas.push({ origem: 'pagina', url: result.pagina, metodo: '—', status: '—', tipo: 'text/html', corpo: SemConta.limpar(a.html), trechos: [SemConta.limpar(a.texto)], seletor: a.seletor, pagina: result.pagina, quando: Date.now() });
      novos++;
    }
  }
  await chrome.storage.local.set({ capturas });
  mostrarEstado(novos ? `${novos} bloco(s) com o código capturados da página.` : 'O código não aparece no texto desta página.', !novos);
};

/**
 * O conteúdo principal da página inteiro (sem cabeçalho e rodapé, onde ficam
 * os dados da conta), para quando a lista não cita o código (similares da
 * CHG). Fotos embutidas em base64 saem: são enormes e não servem ao leitor.
 */
function conteudoDaPagina() {
  const raiz = document.querySelector('main, #content, [role="main"]') ?? document.body;
  const copia = raiz.cloneNode(true);
  copia.querySelectorAll('script, style, svg, header, footer, nav').forEach((el) => el.remove());
  copia.querySelectorAll('img[src^="data:"]').forEach((img) => img.setAttribute('src', '[foto]'));
  return { pagina: location.href, seletor: raiz.tagName.toLowerCase() + (raiz.id ? `#${raiz.id}` : ''), html: copia.outerHTML.slice(0, 500000), texto: raiz.innerText.slice(0, 20000) };
}

/**
 * Os scripts do código-fonte cru da página (como o leitor recebe ao pedir a
 * página, antes de rodar): é onde ficam dados que a página monta na tela
 * depois de abrir (similares da CHG). Fotos em base64 saem.
 */
async function scriptsDoCodigoFonte() {
  const fonte = await (await fetch(location.href, { credentials: 'include' })).text();
  const doc = new DOMParser().parseFromString(fonte, 'text/html');
  const scripts = [...doc.querySelectorAll('script:not([src])')]
    .map((s) => s.textContent.replace(/data:image\/[a-z]+;base64,[A-Za-z0-9+/=\\]+/g, '[foto]').trim())
    .filter(Boolean);
  return { pagina: location.href, texto: scripts.join('\n/* ---- */\n').slice(0, 500000) };
}

const capturarConteudo = async () => {
  const aba = await abaAtual();
  const [{ result }] = await chrome.scripting.executeScript({ target: { tabId: aba.id }, func: conteudoDaPagina });
  const { capturas } = await chrome.storage.local.get({ capturas: [] });
  capturas.push({
    origem: 'pagina', url: result.pagina, metodo: '—', status: '—', tipo: 'text/html', corpo: SemConta.limpar(result.html),
    trechos: [SemConta.limpar(result.texto)], seletor: result.seletor, pagina: result.pagina, quando: Date.now(),
  });
  const [{ result: fonte }] = await chrome.scripting.executeScript({ target: { tabId: aba.id }, func: scriptsDoCodigoFonte });
  capturas.push({
    origem: 'codigo-fonte', url: fonte.pagina, metodo: 'GET', status: '—', tipo: 'text/javascript', corpo: SemConta.limpar(fonte.texto),
    trechos: [], seletor: 'script:not([src])', pagina: fonte.pagina, quando: Date.now(),
  });
  await chrome.storage.local.set({ capturas });
  mostrarEstado(`Conteúdo da página e scripts do código-fonte capturados (${result.seletor}).`);
};

const exportar = async () => {
  const dados = await chrome.storage.local.get(['gravacao', 'capturas']);
  const arquivo = new Blob([JSON.stringify(dados, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(arquivo);
  a.download = `gravacao-${new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-')}.json`;
  a.click();
  URL.revokeObjectURL(a.href);
};

const limpar = async () => {
  await chrome.storage.local.set({ capturas: [] });
  chrome.action.setBadgeText({ text: '' });
};

const desenhar = (capturas = []) => {
  $('total').textContent = capturas.length;
  $('lista').replaceChildren(
    ...capturas.map((c) => {
      const li = document.createElement('li');
      const hora = new Date(c.quando).toLocaleTimeString('pt-BR');
      li.innerHTML = `<span class="selo"></span><b></b><div class="meta"></div><details><summary>trechos (${c.ocorrencias ?? c.trechos?.length ?? 0})</summary><pre></pre></details><details><summary>corpo (${(c.corpo?.length ?? 0).toLocaleString('pt-BR')} caracteres)</summary><pre></pre></details>`;
      // textContent, nunca innerHTML com dado do site: o conteúdo capturado não é confiável
      li.querySelector('.selo').textContent = c.origem;
      li.querySelector('b').textContent = `${c.metodo} ${c.status}`;
      li.querySelector('.meta').textContent = `${hora} · ${c.termo ? `achado por ${c.termo} · ` : ''}${c.url}${c.seletor ? ` · ${c.seletor}` : ''}`;
      const [trechos, corpo] = li.querySelectorAll('pre');
      trechos.textContent = (c.trechos ?? []).join('\n---\n');
      corpo.textContent = (c.corpo ?? '').slice(0, 5000);
      return li;
    })
  );
};

$('iniciar').addEventListener('click', () => iniciar().catch((e) => mostrarEstado(e.message, true)));
$('parar').addEventListener('click', () => parar().catch((e) => mostrarEstado(e.message, true)));
$('capturar-pagina').addEventListener('click', () => capturarPagina().catch((e) => mostrarEstado(e.message, true)));
$('capturar-conteudo').addEventListener('click', () => capturarConteudo().catch((e) => mostrarEstado(e.message, true)));
$('exportar').addEventListener('click', exportar);
$('limpar').addEventListener('click', limpar);

chrome.storage.onChanged.addListener((m) => {
  if (m.capturas) desenhar(m.capturas.newValue);
  const g = m.gravacao?.newValue;
  if (g?.ids?.length) mostrarEstado(`Gravando "${g.codigo}" em ${g.origem}. Ids da peça: ${g.ids.join(', ')}`);
});
chrome.storage.local.get(['gravacao', 'capturas']).then(({ gravacao, capturas }) => {
  desenhar(capturas);
  if (gravacao) {
    $('codigo').value = gravacao.codigo;
    atualizarBotoes(true);
    mostrarEstado(`Gravando "${gravacao.codigo}" em ${gravacao.origem}.`);
  }
});
