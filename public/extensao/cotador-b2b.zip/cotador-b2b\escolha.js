/**
 * Regra de escolha, igual para todos os B2Bs (definida pelo Elias).
 *
 * Cada leitor de site devolve uma lista de ofertas no formato comum:
 *   { fornecedor, codigo, local, emSP, preco, quantidade, disponivel, proximidade }
 *   - quantidade: número de unidades, ou null quando o site só diz sim/não
 *   - disponivel: true se dá para comprar ali (quantidade > 0 quando houver)
 *   - proximidade: ordem de perto para longe de Pirassununga (1 = mais perto)
 *
 * Script comum, sem import/export, como o correspondencia.js.
 */
(() => {
  const PRAZO = {
    pirassununga: '2 a 3 dias',
    outraLoja: '3 a 4 dias',
    foraDoEstado: '7 a 10 dias',
  };

  // Menor preço; empate → mais próximo; empate → mais unidades
  const melhorPrimeiro = (a, b) =>
    a.preco - b.preco ||
    (a.proximidade ?? Infinity) - (b.proximidade ?? Infinity) ||
    (b.quantidade ?? 0) - (a.quantidade ?? 0);

  const primeiro = (ofertas) => [...ofertas].sort(melhorPrimeiro)[0] ?? null;

  const escolher = (ofertas, { loja = 'Pirassununga' } = {}) => {
    const disponiveis = ofertas.filter((o) => o.disponivel && o.preco > 0);
    const emSP = primeiro(disponiveis.filter((o) => o.emSP));
    if (emSP) {
      const prazo = /pirassununga/i.test(loja) ? PRAZO.pirassununga : PRAZO.outraLoja;
      return { situacao: 'SP', oferta: emSP, prazo };
    }
    const fora = primeiro(disponiveis);
    if (fora) return { situacao: 'FORA DO ESTADO', oferta: fora, prazo: PRAZO.foraDoEstado };
    return { situacao: 'SEM ESTOQUE', oferta: null, prazo: null };
  };

  // Entre fornecedores: SP primeiro, depois fora do estado, depois sem oferta;
  // dentro de cada grupo, menor preço. Recebe [{ escolha }] e devolve ordenado.
  const PESO = { SP: 0, 'FORA DO ESTADO': 1 };
  const ordenarFornecedores = (resultados) =>
    [...resultados].sort((a, b) => {
      const pa = PESO[a.escolha?.situacao] ?? 2;
      const pb = PESO[b.escolha?.situacao] ?? 2;
      return pa - pb || (pa < 2 ? a.escolha.oferta.preco - b.escolha.oferta.preco : 0);
    });

  // Similares: no modo "sim" (vendedor marcou) busca sempre; no "auto" só
  // quando a peça pedida não tem estoque em SP.
  const buscarSimilares = (modo, escolhaDaPeca) =>
    modo === 'sim' || (modo === 'auto' && escolhaDaPeca.situacao !== 'SP');

  // Recebe [{ peca, ofertas }] e devolve [{ peca, escolha }] para mostrar:
  // "sim" mostra todos com estoque (SP ou fora, com a tag); "auto" só os de SP.
  const similaresParaMostrar = (similares, modo, opcoes) =>
    ordenarFornecedores(similares.map((s) => ({ peca: s.peca, escolha: escolher(s.ofertas, opcoes) })))
      .filter((s) => (modo === 'auto' ? s.escolha.situacao === 'SP' : s.escolha.situacao !== 'SEM ESTOQUE'));

  globalThis.Escolha = { escolher, ordenarFornecedores, buscarSimilares, similaresParaMostrar, PRAZO };
})();
