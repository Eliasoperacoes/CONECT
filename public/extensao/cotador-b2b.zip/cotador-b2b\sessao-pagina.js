/**
 * Roda no MUNDO DA PÁGINA (world: MAIN) dos B2Bs que usam chave de acesso
 * em cabeçalho (DPK) ou campos de sessão no corpo da busca (Sky, Furacão). Lembra, só na memória desta aba, os cabeçalhos que o
 * próprio site manda para a API dele, para o leitor repetir a chamada do
 * mesmo jeito. Nada sai da página: some ao fechar ou recarregar a aba, e o
 * site renova a chave sozinho a cada chamada.
 */
(() => {
  if (window.__cotadorSessao) return;
  const cabecalhos = {}; // origem da API → { nome: valor }
  const formulario = {}; // campos de sessão que o site manda no corpo (Sky: csrf_token)
  window.__cotadorSessao = {
    cabecalhos: (origem) => ({ ...cabecalhos[origem] }),
    campo: (nome) => formulario[nome] ?? null,
    // A primeira API externa cujo endereço bate (ex.: /algolia\.net$/)
    porHost: (padrao) => {
      const origem = Object.keys(cabecalhos).find((o) => padrao.test(new URL(o).host));
      return origem ? { origem, cabecalhos: { ...cabecalhos[origem] } } : null;
    },
  };

  const guardar = (url, nome, valor) => {
    try {
      const origem = new URL(url, location.href).origin;
      // Do próprio site, só o token XSRF (Furacão), guardado como campo
      if (origem === location.origin) {
        if (/^x-xsrf-token$/i.test(nome) && valor) formulario['x-xsrf-token'] = valor;
        return;
      }
      (cabecalhos[origem] ??= {})[nome.toLowerCase()] = valor;
    } catch { /* nunca quebrar o site */ }
  };

  // A busca do Roles/Pellegrino (Algolia) manda a chave no endereço, não no cabeçalho
  const guardarDoEndereco = (url) => {
    try {
      for (const [nome, valor] of new URL(url, location.href).searchParams)
        if (/^x-algolia-(api-key|application-id)$/i.test(nome)) guardar(url, nome, valor);
    } catch { /* idem */ }
  };

  // A Sky manda o token da sessão no formulário da busca (csrf_token=...);
  // a Furacão, o cliente e a unidade no JSON da busca ({"datatable":{...}})
  const CAMPOS = /^(csrf_token|cliente_selecionado|unidade)$/;
  const guardarDoJson = (no, fundo = 0) => {
    if (!no || typeof no !== 'object' || fundo > 3) return;
    for (const [nome, valor] of Object.entries(no)) {
      if (CAMPOS.test(nome) && typeof valor === 'string' && valor) formulario[nome] = valor;
      else guardarDoJson(valor, fundo + 1);
    }
  };
  const guardarDoCorpo = (corpo) => {
    try {
      if (typeof corpo !== 'string') return;
      if (corpo.trimStart().startsWith('{')) return guardarDoJson(JSON.parse(corpo));
      if (!corpo.includes('=')) return;
      for (const [nome, valor] of new URLSearchParams(corpo)) if (CAMPOS.test(nome) && valor) formulario[nome] = valor;
    } catch { /* idem */ }
  };

  const abrir = XMLHttpRequest.prototype.open;
  const definir = XMLHttpRequest.prototype.setRequestHeader;
  const enviar = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function (corpo) {
    guardarDoCorpo(corpo);
    return enviar.apply(this, arguments);
  };
  XMLHttpRequest.prototype.open = function (metodo, url) {
    this.__cotadorUrl = url;
    guardarDoEndereco(url);
    return abrir.apply(this, arguments);
  };
  XMLHttpRequest.prototype.setRequestHeader = function (nome, valor) {
    if (this.__cotadorUrl) guardar(this.__cotadorUrl, nome, valor);
    return definir.apply(this, arguments);
  };

  const fetchOriginal = window.fetch;
  window.fetch = function (entrada, opcoes = {}) {
    try {
      const url = entrada instanceof Request ? entrada.url : String(entrada);
      guardarDoEndereco(url);
      guardarDoCorpo(opcoes.body);
      const h = new Headers(opcoes.headers || (entrada instanceof Request ? entrada.headers : undefined));
      h.forEach((valor, nome) => guardar(url, nome, valor));
    } catch { /* idem */ }
    return fetchOriginal.apply(this, arguments);
  };
})();
