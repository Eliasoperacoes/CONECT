/**
 * Leitor da Barros (ver docs/fornecedores/barros.md).
 *
 * API própria em outro endereço (como a DPK): quem chama passa `buscar(url)`,
 * o fetch da página logada com o Authorization que o próprio site usa, e o
 * `cliente` (o clientsId da sessão do site, lido da página a cada cotação:
 * nunca guardado aqui).
 * Depende de Correspondencia.
 */
(() => {
  const API = 'https://dealer.barros.com.br/v01';
  const FORNECEDOR = 'Barros';
  // Um estoque só, despachado de Mogi Mirim (Elias, 23/10/2026)
  const LOCAL = { local: 'MOGI MIRIM', emSP: true, proximidade: 1 };

  const norm = (s) => Correspondencia.normalizar(s ?? '');
  const consulta = (params) => new URLSearchParams(params).toString();

  /** A lista de itens da resposta; sem ela e sem dizer "zero itens", é erro */
  const itensDa = (r) => {
    if (Array.isArray(r?.ListaItens)) return r.ListaItens;
    if (r && String(r.TotalItens ?? '') === '0') return [];
    throw new Error(`a busca não devolveu a lista de peças (veio: ${JSON.stringify(r)?.slice(0, 80) ?? 'nada'})`);
  };

  const pecaDo = (i) => ({
    id: String(i.ItensId), codigo: i.ItensCodFornec || i.ItensOriginal, descricao: i.ItensDescriB2B?.trim() || i.ItensDescri?.trim() || null,
    marca: i.ItensModelo || i.GrupoNome || null,
  });

  const ofertaDo = (i) => {
    const preco = Number(i.Preco) || 0;
    const quantidade = Number(i.ItensSaldo) || 0;
    return { fornecedor: FORNECEDOR, codigo: i.ItensCodFornec || i.ItensOriginal, ...LOCAL, preco, quantidade, disponivel: quantidade > 0 && preco > 0 };
  };

  // O código do fabricante (W7122, "W57000-18/WL57000-18") ou o da Barros (411000571)
  const ehOCodigo = (i, alvo) => [i.ItensCodFornec, i.ItensOriginal, i.ItensCod].some((c) => norm(c) === alvo);

  const ler = async (codigo, { buscar, cliente }) => {
    const url = `${API}/itens/itens?${consulta({
      Clientesid: cliente, Pagesize: '20', Pagenumber: '1', Gruposid: '0', Categprodid: '0', Subcategid: '0',
      ModelosId: '', Filtro: codigo, Itenscodfornec: '', Veiculoid: '',
    })}`;
    const itens = itensDa(await buscar(url));
    const item = itens.find((i) => ehOCodigo(i, norm(codigo)));
    if (item) return { peca: pecaDo(item), ofertas: [ofertaDo(item)] };
    // Sem a peça (inativa ou sem cadastro), a busca da Barros traz as
    // equivalentes que ela vende: entram como similares (Elias, 23/10/2026)
    const equivalentes = itens.filter((i) => i.Status !== 'Inativo' && Number(i.Preco) > 0).map((i) => ({ peca: pecaDo(i), ofertas: [ofertaDo(i)] }));
    return equivalentes.length ? { peca: null, ofertas: [], similares: equivalentes } : { peca: null, ofertas: [] };
  };

  /** Similares: a lista da Barros para a peça, sem a própria e sem os itens inativos */
  const similares = async (peca, { buscar, cliente }) => {
    const r = await buscar(`${API}/itens/Similares?${consulta({ ClientesId: cliente, Itensid: peca.id })}`);
    return itensDa(r)
      .filter((i) => String(i.ItensId) !== peca.id && i.Status !== 'Inativo')
      .map((i) => ({ peca: pecaDo(i), ofertas: [ofertaDo(i)] }));
  };

  globalThis.Leitores = { ...globalThis.Leitores, barros: { ler, similares } };
})();
