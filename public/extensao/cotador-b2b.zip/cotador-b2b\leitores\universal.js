/**
 * Leitor da Universal Automotive (ver docs/fornecedores/universal.md).
 *
 * Duas chamadas, como o próprio site faz:
 *   1. o autocomplete da busca (`/autocomplete?q=<código>`): a lista de
 *      produtos com o endereço da página de cada um;
 *   2. a página do produto (HTML), que traz o código (`#item_sku`), a marca,
 *      e num script o preço do cliente (`unitPriceDiscount`) e o estoque
 *      (`variants[].qtde_estoque`).
 *
 * O autocomplete acha por texto: o leitor só aceita a página cujo
 * `#item_sku` é o código pedido, e abre no máximo PAGINAS candidatos.
 *
 * Quem chama passa json(caminho) e texto(caminho) (GET na aba logada).
 * Depende de Correspondencia e DOMParser.
 */
(() => {
  const FORNECEDOR = 'Universal Automotive';
  const PAGINAS = 4;
  const norm = (s) => Correspondencia.normalizar(s ?? '');
  const vencida = () => Object.assign(new Error('sessão vencida'), { sessao: true });

  /** `var nome = 16.7944;` → 16.7944 */
  const numero = (pagina, nome) => {
    const m = pagina.match(new RegExp(`var\\s+${nome}\\s*=\\s*(-?[\\d.]+)\\s*;`));
    return m ? Number(m[1]) : null;
  };

  /** `var variants = '[...]';` → a lista (JSON dentro de uma string JS) */
  const variantes = (pagina) => {
    const m = pagina.match(/var\s+variants\s*=\s*'((?:\\.|[^'\\])*)'\s*;/);
    if (!m) return [];
    try { return JSON.parse(m[1].replace(/\\'/g, "'")); } catch { return []; }
  };

  // A linha da tabela de descrição pelo título ("Marca:", "Código do Produto:")
  const campo = (doc, titulo) =>
    [...doc.querySelectorAll('#desc_tab tr, table tr')]
      .find((tr) => tr.querySelector('th')?.textContent.trim().toLowerCase().startsWith(titulo))
      ?.querySelector('td')?.textContent.trim() || null;

  const lerProduto = (pagina) => {
    // Sem login a página não traz o preço do cliente
    if (/var\s+customer\s*=\s*false/.test(pagina)) throw vencida();
    const doc = new DOMParser().parseFromString(pagina, 'text/html');
    return {
      codigo: doc.querySelector('#item_sku')?.textContent.trim() || campo(doc, 'código do produto'),
      marca: campo(doc, 'marca:'),
      original: campo(doc, 'número original'),
      preco: numero(pagina, 'unitPriceDiscount') ?? numero(pagina, 'unitPrice'),
      variantes: variantes(pagina),
    };
  };

  const ler = async (codigo, { json, texto }) => {
    const alvo = norm(codigo);
    const lista = await json(`/autocomplete?${new URLSearchParams({ q: codigo })}`);
    if (!Array.isArray(lista)) throw new Error(`a busca não devolveu a lista de peças (veio: ${JSON.stringify(lista)?.slice(0, 80) ?? 'nada'})`);
    // O endereço termina em "-<código>-<loja>": confere esses primeiro
    const candidatos = [...lista].sort((a, b) => norm(b.url).includes(alvo) - norm(a.url).includes(alvo)).slice(0, PAGINAS);
    for (const item of candidatos) {
      const produto = lerProduto(await texto(String(item.url).replace(/^https?:\/\/[^/]+/, '')));
      if (norm(produto.codigo) !== alvo) continue;
      const preco = Math.round((produto.preco ?? 0) * 100) / 100;
      const quantidade = Number(produto.variantes[0]?.qtde_estoque) || 0;
      return {
        peca: { id: String(item.id), codigo: produto.codigo, marca: produto.marca, descricao: item.text ?? null, original: produto.original },
        ofertas: [{
          fornecedor: FORNECEDOR, codigo: produto.codigo, local: 'Universal', emSP: true, proximidade: null,
          preco, quantidade, disponivel: quantidade > 0 && preco > 0,
        }],
      };
    }
    return { peca: null, ofertas: [] };
  };

  globalThis.Leitores = { ...globalThis.Leitores, universal: { ler, PAGINAS } };
})();
