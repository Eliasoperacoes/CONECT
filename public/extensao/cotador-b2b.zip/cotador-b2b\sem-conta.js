/**
 * O que nunca sai da página na gravação: credencial e dados da conta.
 *
 * Uma regra, um lugar: usada pela captura das chamadas (captura-pagina.js,
 * no mundo da página) e pelo "Capturar da página" (painel.js). Script comum,
 * sem import/export, como o correspondencia.js.
 */
(() => {
  // Credencial: o nome do campo fica (o leitor precisa saber que ele existe),
  // o valor vira [oculto]. Também os dados da conta: Furacão manda o CNPJ em
  // "cliente_selecionado"; a Disape responde razão social, limite de crédito e
  // token de WhatsApp; a Lucios (ASP.NET) põe código e nome do cliente, o
  // vendedor e a posição financeira em campos do formulário, e o __VIEWSTATE
  // é base64 do estado da tela (dá para decodificar)
  // A Rolemar põe no script da página o parceiro (endereço, WhatsApp, código
  // no ERP, id da loja) e o código de parceiro em cada produto (codparc)
  const SECRETO = /auth|cookie|token|key|secret|session|senha|password|csrf|xsrf|cnpj|cpf|e-?mail|cliente|clicod|vend[ae]n?d[eo]r|fullname|firstname|lastname|limit|razao|telefone|celular|saldo|atraso|duplicata|ponto|inativo|mediacompra|obsfinanceira|viewstate|endereco|whats|cod_?erp|codparc|idloja|orcamento_contato|customer_?id/i;
  const ocultar = (nome, valor) => (SECRETO.test(nome) ? '[oculto]' : valor);

  // No corpo (ida e volta): formulário (a=1&csrf_token=...) ou JSON ("token":"...")
  const ocultarCorpo = (texto) =>
    typeof texto !== 'string'
      ? texto
      : texto
          // Campo do formulário no HTML devolvido (Lucios): <input name="...txtSaldo" value="...">
          .replace(/<input\b[^>]*>/gi, (tag) => {
            const nome = /\bname=(["'])(.*?)\1/i.exec(tag)?.[2];
            return nome && SECRETO.test(nome) ? tag.replace(/\bvalue=(["'])(?:(?!\1)[\s\S])*\1/i, 'value=$1[oculto]$1') : tag;
          })
          .replace(/(<textarea\b[^>]*\bname=(["'])([^"']*)\2[^>]*>)([\s\S]*?)(<\/textarea>)/gi, (t, abre, _q, nome, conteudo, fecha) =>
            SECRETO.test(nome) && conteudo.trim() ? `${abre}[oculto]${fecha}` : t)
          // Resposta parcial do ASP.NET (UpdatePanel): "|hiddenField|__VIEWSTATE|valor|"
          .replace(/(\|hiddenField\|)([^|]*)\|([^|]*)/g, (t, ini, nome) => (SECRETO.test(nome) ? `${ini}${nome}|[oculto]` : t))
          .replace(/(^|&)([^=&\s]*)=([^&]*)/g, (t, ini, nome) => (SECRETO.test(nome) ? `${ini}${nome}=[oculto]` : t))
          .replace(/"([^"]*)"(\s*:\s*)"(?:[^"\\]|\\.)*"/g, (t, nome, sep) => (SECRETO.test(nome) ? `"${nome}"${sep}"[oculto]"` : t))
          // Script da página: token = '...', { csrf: "..." }. Atributo de evento
          // (onkeypress, onkeydown) é código da tela, não segredo: o "key" do
          // nome escondia o que o Enter faz na Lucios (24/10/2026)
          .replace(/(['"]?)([\w$.-]+)\1(\s*[:=]\s*)(['"`])(?:\\.|(?!\4)[^\\])*\4/g, (t, aspa, nome, sep, q) =>
            SECRETO.test(nome) && !/^on[a-z]+$/i.test(nome) ? `${aspa}${nome}${aspa}${sep}${q}[oculto]${q}` : t)
          // Bloco do Google Tag Manager com o cliente logado (RMP/Disape, Magento):
          // "gtm":{"customerLoggedIn":1,"customerId":"…","id":"…"}
          .replace(/"gtm"(\s*:\s*)\{[^{}]*"customerLoggedIn"[^{}]*\}/g, '"gtm"$1"[oculto]"')
          // Número solto, sem aspas (Rolemar: cod_erp: 99999 no script; "codparc":99999 no JSON)
          .replace(/(['"]?)([\w$.-]+)\1(\s*:\s*)(\d[\d.]*)(?=\s*[,}\n])/g, (t, aspa, nome, sep) =>
            SECRETO.test(nome) ? `${aspa}${nome}${aspa}${sep}"[oculto]"` : t)
          // Token de formulário do Joomla (CHG): 32 hexadecimais, às vezes no próprio nome do campo
          .replace(/(?<![\w-])[a-f0-9]{32}(?![\w-])/gi, '[oculto]');

  // Em qualquer texto: CNPJ e e-mail. CNPJ só quando os dígitos verificadores
  // batem: SKU de 14 dígitos (Disape) não é CNPJ e fica. A barra pode vir
  // escapada no JSON ("11.222.333\/0001-81")
  const CNPJ = /(?<!\d)\d{2}\.?\d{3}\.?\d{3}(?:\\?\/)?\d{4}-?\d{2}(?!\d)/g;
  const EMAIL = /[\w.+-]+@[\w-]+(\.[\w-]+)+/g;
  const digito = (base) => {
    let soma = 0;
    let peso = base.length - 7;
    for (const c of base) {
      soma += Number(c) * peso--;
      if (peso < 2) peso = 9;
    }
    return soma % 11 < 2 ? 0 : 11 - (soma % 11);
  };
  const ehCnpj = (texto) => {
    const d = texto.replace(/\D/g, '');
    if (d.length !== 14 || /^(\d)\1+$/.test(d)) return false;
    const a = digito(d.slice(0, 12));
    return d.endsWith(`${a}${digito(d.slice(0, 12) + a)}`);
  };
  // Linha de identificação do cliente na página (CHG: "Cliente : RAZÃO - CNPJ - Codigo : 0000").
  // No HTML ela continua na linha de baixo, recuada ("\n\t\t00001931 - Filial : CPS")
  const LINHA_CLIENTE = /(Cliente|Raz[ãa]o\s+Social)(\s*(?:<[^>]*>\s*)*:\s*(?:<[^>]*>\s*)*)[^<\n]+(?:\n[ \t]+[^<\n\s][^<\n]*)*/gi;
  // Saudação com o nome de quem está logado (Rufato: "OLÁ, FULANA DE TAL. SEJA BEM VINDO(A)!")
  const SAUDACAO = /(Ol[áa]|Bem[- ]vind[oa](?:\(a\))?|Seja bem[- ]vind[oa](?:\(a\))?)(,?\s+)[^<\n.!]+/gi;
  // Parâmetros da proteção da Cloudflare no código-fonte (trazem um token da visita)
  const CLOUDFLARE = /(__CF\$cv\$params\s*=\s*)\{[^}]*\}/g;
  // Razão social em qualquer lugar, venha no campo que vier (Rolemar: "nome"
  // e "loja" do usuário no script): nome em maiúsculas terminado em LTDA etc.
  // (sem "ME"/"EPP": descrição de peça pode terminar assim)
  // O "&" pode vir escapado no HTML (&amp; / &amp;amp;)
  const EMPRESA = /[A-ZÀ-Ú0-9](?:[A-ZÀ-Ú0-9&;.,'\- ]|&(?:[a-z]+;)+){2,80}?\s(LTDA|EIRELI|S\/A|S\.A\.?)(?![A-Za-z])\.?/g;
  const semDocumento = (texto) =>
    typeof texto === 'string'
      ? texto
          .replace(CNPJ, (t) => (ehCnpj(t) ? '[documento]' : t))
          .replace(EMAIL, '[email]')
          .replace(LINHA_CLIENTE, '$1$2[oculto]')
          .replace(SAUDACAO, '$1$2[oculto]')
          .replace(CLOUDFLARE, '$1{[oculto]}')
          .replace(EMPRESA, '[empresa]')
      : texto;

  /** Tudo junto: campos de credencial e da conta, CNPJ e e-mail */
  const limpar = (texto) => semDocumento(ocultarCorpo(texto));

  // No endereço: parâmetro da conta na consulta e o código do usuário no
  // caminho (Rolemar: api.../v1/notifications/<código no ERP>)
  const USUARIO = /^(uid|user_?id|usuario|id_?usuario)$/i;
  const CAMINHO_DA_CONTA = /(\/(?:notifications|notificacoes|usuarios?|users?|clientes?|parceiros?)\/)\d+(?=[/?#]|$)/gi;
  const limparUrl = (url) =>
    typeof url === 'string'
      ? semDocumento(url
          .replace(CAMINHO_DA_CONTA, '$1[oculto]')
          .replace(/([?&])([^=&#]*)=([^&#]*)/g, (t, ini, nome) => (SECRETO.test(nome) || USUARIO.test(nome) ? `${ini}${nome}=[oculto]` : t)))
      : url;

  globalThis.SemConta = { ocultar, ocultarCorpo, semDocumento, limpar, limparUrl, ehCnpj };
})();
