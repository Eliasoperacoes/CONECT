/**
 * Leitor da Lucios (ver docs/fornecedores/lucios.md).
 *
 * O site é a tela de montar pedido (ASP.NET WebForms). O leitor repete o que
 * o vendedor faz nela, por "postback" parcial (UpdatePanel), sem mexer na aba:
 *   1. "Incluir" item (abre o editor do item);
 *   2. o código em "Outras Referências" e "Buscar Produto" (o Enter do
 *      campo), página inteira: a grade com as peças que têm o código;
 *   3. a linha cujo Cód. Fabr. é o código: a peça aberta, com o preço do
 *      cliente, o estoque e a lista "Similares".
 * Similares: o código Lucios de cada um no campo "Código Lucios", um por vez.
 *
 * Nunca clica em "Aplicar Item" nem "Salvar Pedido".
 *
 * Quem chama passa postback(campos, { parcial }) (cotacao.js, tipo aspnet).
 * Depende de Correspondencia e DOMParser.
 */
(() => {
  const FORNECEDOR = 'Lucios';
  const P = 'ctl00$cphMaster$';
  const GERENTE = `${P}ToolkitScriptManager1`;
  const BUSCA = 4; // no máximo N peças da grade abertas
  const SIMILARES = 6;
  const norm = (s) => Correspondencia.normalizar(s ?? '');

  /** "9.100,00" / "18200,00" → número; vazio → null */
  const reais = (t) => {
    const s = String(t ?? '').trim();
    if (!s) return null;
    const n = Number(s.replace(/\./g, '').replace(',', '.'));
    return Number.isFinite(n) ? n : null;
  };
  const documento = (html) => new DOMParser().parseFromString(`<!doctype html><html><body>${html}</body></html>`, 'text/html');
  const valor = (doc, campo) => doc.querySelector(`[name="${P}${campo}"]`)?.getAttribute('value')?.trim() ?? '';

  /** O item aberto no painel upItens: a peça e a oferta (preço do cliente e estoque) */
  const lerItem = (html) => {
    if (!html) return null;
    const doc = documento(html);
    const id = valor(doc, 'txtProdutoCodigo');
    if (!id) return null;
    const unitario = reais(valor(doc, 'txtItemPrecoUnit'));
    const promocao = reais(valor(doc, 'txtItemPrecoPromo'));
    const preco = promocao > 0 && !(unitario > 0 && unitario <= promocao) ? promocao : unitario;
    // Sem venda a tela troca o estoque pelo aviso, e o preço que sobra não vale
    const indisponivel = /indispon[ií]vel\s+para\s+venda/i.test(doc.body.textContent);
    const quantidade = indisponivel ? 0 : Number(valor(doc, 'txtItemQtdeEstoque').replace(/\D/g, '')) || 0;
    const peca = {
      id, codigo: valor(doc, 'txtItemCodFabr'), marca: valor(doc, 'txtFornecedor') || null,
      descricao: doc.querySelector('#ctl00_cphMaster_lblProduto')?.textContent.trim() || null,
    };
    return {
      peca,
      oferta: {
        fornecedor: FORNECEDOR, codigo: peca.codigo, local: 'Lucios', emSP: true, proximidade: null,
        preco: indisponivel ? null : preco, quantidade, disponivel: !indisponivel && quantidade > 0 && preco > 0,
      },
    };
  };

  /** "Similares" da peça aberta (painel upEspelho): código Lucios e marca */
  const lerEspelho = (html) => {
    if (!html) return [];
    return [...documento(html).querySelectorAll('#ctl00_cphMaster_gvEspelho tr')]
      .map((tr) => [...tr.querySelectorAll('td')].map((td) => td.textContent.trim()))
      .filter((c) => c.length >= 2 && /^\d+$/.test(c[0]))
      .map(([id, marca]) => ({ id, marca: marca || null }));
  };

  /** Linhas da grade da pesquisa (gvBusca): código Lucios, Cód. Fabr., descrição, marca */
  const lerGrade = (html) =>
    [...documento(html).querySelectorAll('#ctl00_cphMaster_gvBusca tr')]
      .map((tr) => [...tr.querySelectorAll('td')].map((td) => td.textContent.trim()))
      .filter((c) => c.length >= 4 && /^\d+$/.test(c[0]))
      .map(([id, codigo, descricao, marca]) => ({ id, codigo, descricao, marca }));

  // Passo que não respondeu como nas gravações: erro com o nome do passo, não
  // "sem resultado" (que diria ao balconista que a Lucios não tem a peça)
  const incluir = async (postback) => {
    const d = await postback({ [GERENTE]: `${P}upItens|${P}btnIncluir`, __EVENTTARGET: '', __EVENTARGUMENT: '', [`${P}btnIncluir.x`]: '0', [`${P}btnIncluir.y`]: '0' });
    if (!d.paineis.ctl00_cphMaster_upItens?.includes('txtOutrasRef')) throw new Error('o "Incluir" da tela de Pedidos não abriu o item');
  };

  const abrirPorCodigoLucios = async (id, postback) => {
    const d = await postback({
      [GERENTE]: `${P}upItens|${P}txtProdutoCodigo`, __EVENTTARGET: `${P}txtProdutoCodigo`, __EVENTARGUMENT: '',
      [`${P}txtProdutoCodigo`]: id,
    });
    return lerItem(d.paineis.ctl00_cphMaster_upItens);
  };

  const abrirDaGrade = async (id, postback) => {
    const d = await postback({ [GERENTE]: `${P}UpdatePanel2|${P}gvBusca`, __EVENTTARGET: `${P}gvBusca`, __EVENTARGUMENT: `Selecionar$${id}` });
    return { item: lerItem(d.paineis.ctl00_cphMaster_upItens), espelho: lerEspelho(d.paineis.ctl00_cphMaster_upEspelho) };
  };

  const resultado = (item, espelho) => ({
    peca: { ...item.peca, espelho: espelho.filter((s) => s.id !== item.peca.id) },
    ofertas: [item.oferta],
  });

  const ler = async (codigo, { postback, rastro = [] }) => {
    const alvo = norm(codigo);
    const peca = (item) => (item ? `${item.peca.id} (Cód. Fabr. ${item.peca.codigo || 'vazio'}, ${item.peca.marca ?? 'sem marca'})` : 'nenhuma peça');
    await incluir(postback);
    // A janela "Busca de Produtos": campo "Referência" (txtProduto) e o
    // Pesquisar dele (o Enter do campo clica nele: pesquisarProdutoEnter).
    // O botão é de IMAGEM: o clique vai como nome.x / nome.y, e é assim que o
    // ASP.NET sabe que ele foi apertado (só o nome, a busca não roda: voltava
    // a tela em branco). Fica fora dos UpdatePanels: página inteira
    const pagina = await postback({
      [`${P}txtProduto`]: codigo, [`${P}btnBuscarProduto.x`]: '0', [`${P}btnBuscarProduto.y`]: '0', __EVENTTARGET: '', __EVENTARGUMENT: '',
    }, { parcial: false });
    if (!/gvBusca|lblResultado/.test(pagina)) throw new Error('a pesquisa de produtos não respondeu');
    const grade = lerGrade(pagina);
    const linhas = grade.filter((l) => norm(l.codigo) === alvo);
    const contador = /id="ctl00_cphMaster_lblResultado"[^>]*>([^<]*)</.exec(pagina)?.[1]?.trim();
    rastro.push(`pesquisa ${codigo}: "${contador ?? 'sem contador'}", ${grade.length} linhas na grade, ${linhas.length} com o Cód. Fabr. ${codigo}`);
    if (!grade.length) {
      // Como a página voltou: o que ficou nos campos de busca e se houve aviso
      const doc = documento(pagina);
      const ficou = ['txtOutrasRef', 'txtProduto', 'txtCodigoFabrica'].map((c) => `${c}="${valor(doc, c)}"`).join(', ');
      const avisos = [...pagina.matchAll(/alert\(\s*['"]([^'"]{1,120})/g)].map((m) => m[1]);
      rastro.push(`a página voltou com ${ficou}${avisos.length ? `; aviso: ${avisos.join(' | ')}` : ''}`);
    }
    const ids = [...new Set(linhas.map((l) => l.id))].slice(0, BUSCA);
    let achado = null;
    const outras = [];
    for (const id of ids) {
      const { item, espelho } = await abrirDaGrade(id, postback);
      rastro.push(`linha ${id} da grade: abriu ${peca(item)}`);
      if (!item || item.peca.id !== id) continue;
      if (!achado) achado = { item, espelho };
      else outras.push({ id, marca: item.peca.marca });
    }
    if (!achado && ids.length) throw new Error('a peça apareceu na pesquisa mas não abriu');
    if (!achado) {
      // Sem a peça, a pesquisa por Referência traz as que a citam: são as
      // equivalentes que a Lucios vende (OC90 → WO130, OR130; Elias,
      // 11/11/2026). Uma linha por carro: cada código Lucios abre uma vez
      const equivalentes = [...new Set(grade.map((l) => l.id))].slice(0, SIMILARES).map((id) => ({ id }));
      if (!equivalentes.length) return { peca: null, ofertas: [] };
      const lista = await abrirLista(equivalentes, postback);
      rastro.push(`sem a peça: ${lista.length} de ${equivalentes.length} equivalentes da pesquisa abertas como similares`);
      if (!lista.length) throw new Error('as equivalentes da pesquisa não abriram');
      return { peca: null, ofertas: [], similares: lista };
    }
    // O mesmo código em outra marca entra como similar
    return resultado(achado.item, [...outras, ...achado.espelho]);
  };

  /** Cada peça aberta pelo código Lucios, uma por vez (o estado da tela é um só) */
  const abrirLista = async (lista, postback) => {
    const saida = [];
    for (const s of lista) {
      const item = await abrirPorCodigoLucios(s.id, postback);
      if (!item || item.peca.id !== s.id || !item.peca.codigo) continue;
      saida.push({ peca: item.peca, ofertas: [item.oferta] });
    }
    return saida;
  };

  const similares = async (peca, { postback }) => {
    const lista = (peca.espelho ?? []).slice(0, SIMILARES);
    const saida = await abrirLista(lista, postback);
    if (lista.length && !saida.length) throw new Error('os similares não abriram');
    return saida;
  };

  globalThis.Leitores = { ...globalThis.Leitores, lucios: { ler, similares, lerItem, lerEspelho, lerGrade, BUSCA, SIMILARES } };
})();
