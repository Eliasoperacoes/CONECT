/**
 * Ponte com o CONECTA (content script, mundo isolado, só nas origens do
 * CONECTA). A página da estação de compras pergunta por `postMessage`; aqui
 * se repassa ao service worker, e a resposta volta só para esta janela.
 *
 * A extensão não fala com o banco: quem grava é o CONECTA, com o login de
 * quem está ali. Aqui não passa credencial nenhuma, nem do CONECTA nem dos
 * B2Bs.
 *
 * Mensagem da página: { marca: 'cotador-b2b', direcao: 'pedido', id, tipo, dados }
 * Resposta:           { marca: 'cotador-b2b', direcao: 'resposta', id, ok, dados | erro }
 */
(() => {
  const MARCA = 'cotador-b2b';
  const TIPOS = ['ola', 'cotar'];

  /** Instala a ponte numa janela; `enviar` leva o pedido ao service worker. */
  const instalar = (janela, enviar) => {
    janela.addEventListener('message', async (evento) => {
      const m = evento.data;
      // Só a própria página, na própria origem, com a marca e um tipo conhecido
      if (evento.source !== janela || evento.origin !== janela.location.origin) return;
      if (!m || m.marca !== MARCA || m.direcao !== 'pedido' || !TIPOS.includes(m.tipo)) return;
      let resposta;
      try {
        resposta = { ok: true, dados: await enviar({ tipo: m.tipo, dados: m.dados ?? null }) };
      } catch (e) {
        resposta = { ok: false, erro: String(e?.message ?? e) };
      }
      janela.postMessage({ marca: MARCA, direcao: 'resposta', id: m.id, ...resposta }, janela.location.origin);
    });
  };

  globalThis.ConectaPonte = { instalar, MARCA };

  if (globalThis.chrome?.runtime?.id && !globalThis.__conectaPonte) {
    globalThis.__conectaPonte = true;
    instalar(window, async (pedido) => {
      const r = await chrome.runtime.sendMessage({ conecta: pedido });
      if (!r?.ok) throw new Error(r?.erro ?? 'a extensão não respondeu');
      return r.dados;
    });
  }
})();
