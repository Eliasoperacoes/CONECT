/**
 * Leitor da CHG Automotiva (Joomla; ver docs/fornecedores/chg.md).
 *
 * Uma chamada (ou poucas): a lista de produtos que a própria tela de busca
 * carrega (`GetListaProd`, JSON servido como HTML), com o código da CHG
 * (`produto`, ex.: 0000383), o do fornecedor (`codforn`, ex.: 6440), marca,
 * preço e estoque. Cada item traz também a foto em base64: o leitor não usa.
 *
 * A busca é por texto na descrição e vem em páginas (`skip`): o código do
 * fornecedor sozinho ("6440") pode cair longe da 1ª página. Por isso o
 * leitor segue as páginas até achar, no máximo PAGINAS.
 *
 * Quem chama passa json(caminho) (GET, devolve o JSON) e texto(caminho)
 * (GET, devolve o HTML do detalhe, para os similares), na aba logada.
 * Depende de Correspondencia.
 */
(() => {
  const FORNECEDOR = 'CHG Automotiva';
  const PAGINAS = 5;
  const norm = (s) => Correspondencia.normalizar(s ?? '');

  // Bate pelo código da CHG ou pelo do fornecedor
  const ehOCodigo = (i, alvo) => norm(i.produto) === alvo || norm(i.codforn) === alvo;

  const pagina = async (json, codigo, skip) => {
    const caminho = `/portal-do-cliente?${new URLSearchParams({ format: 'raw', view: 'GetListaProd', skip: String(skip), desc: codigo, marca: '', linha: '' })}`;
    const lista = await json(caminho);
    if (!Array.isArray(lista)) throw new Error(`a busca não devolveu a lista de peças (veio: ${JSON.stringify(lista)?.slice(0, 80) ?? 'nada'})`);
    return lista;
  };

  const ler = async (codigo, { json }) => {
    const alvo = norm(codigo);
    let item = null;
    for (let n = 0, skip = 0; n < PAGINAS && !item; n++) {
      const lista = await pagina(json, codigo, skip);
      item = lista.find((i) => ehOCodigo(i, alvo)) ?? null;
      if (!lista.length) break;
      skip += lista.length;
    }
    if (!item) return { peca: null, ofertas: [] };
    const preco = Number(item.preco) || 0;
    const quantidade = Number(item.estoque) || 0;
    return {
      peca: { id: String(item.produto), codigo: item.codforn, codigoChg: String(item.produto), marca: item.marca ?? null, descricao: item.descricao ?? null },
      ofertas: [{
        fornecedor: FORNECEDOR, codigo: item.codforn, local: 'CHG', emSP: true, proximidade: null,
        preco, quantidade, disponivel: quantidade > 0 && preco > 0 && String(item.statusproduto ?? '1') === '1',
      }],
    };
  };

  /**
   * Similares: a página de detalhe da peça não traz o bloco "Produtos
   * Similares" montado; ela traz um script por peça, que a tela desenha depois:
   *   var data = {produto : '0954214', codforn : '10VW0043', ..., precoO : '138.20'};
   *   var elm = DrawProd(data, 180);
   *   $(elm).appendTo($('#sim'));
   * '#sim' são os similares; '#rel' (relacionados) não são.
   */
  const BLOCO = /var\s+data\s*=\s*\{([\s\S]*?)\};\s*var\s+elm\s*=\s*DrawProd\([^)]*\);\s*\$\(elm\)\.appendTo\(\$\(['"]#(\w+)['"]\)\)/g;
  const CAMPO = /(\w+)\s*:\s*'((?:\\.|[^'\\])*)'/g;
  const campos = (corpo) => Object.fromEntries([...corpo.matchAll(CAMPO)].map(([, nome, v]) => [nome, v.replace(/\\(.)/g, '$1')]));

  const similares = async (peca, { texto }) => {
    const caminho = `/portal-do-cliente?${new URLSearchParams({ option: 'com_catalogo', view: 'DetalhesProduto', produto: '', qtd: '', codigo: peca.codigoChg, Add: '1' })}`;
    const pagina = await texto(caminho);
    if (!/DrawProd|Produtos Similares/.test(pagina)) throw new Error('a página de detalhe da peça não veio (sessão vencida?)');
    return [...pagina.matchAll(BLOCO)]
      .filter(([, , destino]) => destino === 'sim')
      .map(([, corpo]) => {
        const i = campos(corpo);
        const preco = Number(i.precoO) || 0;
        const quantidade = Number(i.estoque) || 0;
        return {
          peca: { id: String(i.produto), codigo: i.codforn, codigoChg: String(i.produto), marca: i.marca || null, descricao: i.descricao || null },
          ofertas: [{
            fornecedor: FORNECEDOR, codigo: i.codforn, local: 'CHG', emSP: true, proximidade: null,
            preco, quantidade, disponivel: quantidade > 0 && preco > 0 && String(i.statusproduto ?? '1') === '1',
          }],
        };
      });
  };

  globalThis.Leitores = { ...globalThis.Leitores, chg: { ler, similares, PAGINAS } };
})();
