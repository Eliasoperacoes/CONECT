/**
 * Service worker: abre o painel lateral e guarda as capturas.
 */

chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

// Estação de compras: o CONECTA pergunta pela ponte (conecta-ponte.js)
importScripts('escolha.js', 'cotacao.js');

const atenderConecta = async ({ tipo, dados }) => {
  if (tipo === 'ola') return { versao: chrome.runtime.getManifest().version, sites: await Cotacao.situacaoDosSites() };
  if (tipo === 'cotar') {
    const codigo = String(dados?.codigo ?? '').trim();
    if (codigo.length < 3 || codigo.length > 40) throw new Error('código inválido');
    const modo = dados?.incluirSimilares ? 'sim' : 'auto';
    return { resultados: (await Cotacao.cotarTodos(codigo, modo)).map(Cotacao.paraBanco) };
  }
  throw new Error(`pedido desconhecido: ${tipo}`);
};

// As abas dos B2Bs não dormem nem quando o CONECTA está fechado: a cada 5
// minutos, a mesma conferência da estação marca cada aba para o Chrome não
// descartar e acorda a que dormiu (cotacao.js, protegerAba)
chrome.alarms.create('acordar-abas', { periodInMinutes: 5 });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === 'acordar-abas') Cotacao.situacaoDosSites().catch(() => {});
});

chrome.runtime.onMessage.addListener((msg, remetente, responder) => {
  if (!msg?.conecta) return;
  // Só a ponte, que roda dentro de uma aba do CONECTA
  if (!remetente.tab || remetente.id !== chrome.runtime.id) return;
  atenderConecta(msg.conecta).then(
    (dados) => responder({ ok: true, dados }),
    (e) => responder({ ok: false, erro: e.message })
  );
  return true; // resposta assíncrona
});

const chave = (c) => `${c.metodo} ${c.url} ${c.status} ${c.corpo?.length ?? 0}`;

const MAXIMO_IDS = 20;

chrome.runtime.onMessage.addListener((msg, remetente) => {
  if (msg?.tipo === 'ids') {
    // Ids internos da peça, aprendidos de uma resposta com o código. Ficam na
    // gravação para valer em todas as abas, frames e recarregamentos.
    chrome.storage.local.get('gravacao').then(({ gravacao }) => {
      if (!gravacao) return;
      const antes = gravacao.ids ?? [];
      const ids = [...new Set([...antes, ...msg.ids])].slice(0, MAXIMO_IDS);
      if (ids.length !== antes.length) chrome.storage.local.set({ gravacao: { ...gravacao, ids } });
    });
    return;
  }
  if (msg?.tipo !== 'captura') return;
  chrome.storage.local.get({ capturas: [] }).then(({ capturas }) => {
    // O site costuma repetir a mesma chamada; guarda uma vez só
    if (capturas.some((c) => chave(c) === chave(msg.dados))) return;
    capturas.push({ ...msg.dados, aba: remetente.tab?.id });
    chrome.storage.local.set({ capturas });
    chrome.action.setBadgeText({ text: String(capturas.length) });
  });
});
